/*
Navicat MySQL Data Transfer

Source Server         : DeliverySystem
Source Server Version : 80017
Source Host           : localhost:3306
Source Database       : deliverysystem

Target Server Type    : MYSQL
Target Server Version : 80017
File Encoding         : 65001

Date: 2019-09-06 16:40:34
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for ds_account
-- ----------------------------
DROP TABLE IF EXISTS `ds_account`;
CREATE TABLE `ds_account` (
  `ID` varchar(12) NOT NULL,
  `PSW` varchar(12) NOT NULL,
  `TYPE` varchar(5) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_customer
-- ----------------------------
DROP TABLE IF EXISTS `ds_customer`;
CREATE TABLE `ds_customer` (
  `CID` varchar(12) NOT NULL,
  `NAME` varchar(12) NOT NULL,
  `PHONE` varchar(20) NOT NULL,
  `ADRESS` varchar(30) NOT NULL,
  PRIMARY KEY (`CID`),
  CONSTRAINT `ds_customer_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `ds_account` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_evaluation_rider
-- ----------------------------
DROP TABLE IF EXISTS `ds_evaluation_rider`;
CREATE TABLE `ds_evaluation_rider` (
  `RID` varchar(12) NOT NULL,
  `NAME` varchar(12) NOT NULL,
  `CONTENT` varchar(30) NOT NULL,
  `LEVEL` varchar(5) NOT NULL,
  `TIME` varchar(30) NOT NULL,
  `CID` varchar(12) NOT NULL,
  PRIMARY KEY (`RID`,`CID`,`TIME`),
  KEY `CID` (`CID`),
  CONSTRAINT `ds_evaluation_rider_ibfk_1` FOREIGN KEY (`RID`) REFERENCES `ds_rider` (`RID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ds_evaluation_rider_ibfk_2` FOREIGN KEY (`CID`) REFERENCES `ds_customer` (`CID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_evaluation_store
-- ----------------------------
DROP TABLE IF EXISTS `ds_evaluation_store`;
CREATE TABLE `ds_evaluation_store` (
  `SID` varchar(12) NOT NULL,
  `NAME` varchar(12) DEFAULT NULL,
  `CONTENT` varchar(30) DEFAULT NULL,
  `LEVEL` varchar(5) DEFAULT NULL,
  `TIME` varchar(30) NOT NULL,
  `REPLY` varchar(30) DEFAULT NULL,
  `CID` varchar(12) NOT NULL,
  PRIMARY KEY (`SID`,`CID`,`TIME`),
  KEY `CID` (`CID`),
  CONSTRAINT `ds_evaluation_store_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `ds_store` (`SID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ds_evaluation_store_ibfk_2` FOREIGN KEY (`CID`) REFERENCES `ds_customer` (`CID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_good
-- ----------------------------
DROP TABLE IF EXISTS `ds_good`;
CREATE TABLE `ds_good` (
  `SID` varchar(12) NOT NULL,
  `INTRO` varchar(20) DEFAULT NULL,
  `PRICE` varchar(5) DEFAULT NULL,
  `NAME` varchar(12) NOT NULL,
  PRIMARY KEY (`SID`,`NAME`),
  CONSTRAINT `ds_good_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `ds_store` (`SID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_rider
-- ----------------------------
DROP TABLE IF EXISTS `ds_rider`;
CREATE TABLE `ds_rider` (
  `RID` varchar(12) NOT NULL,
  `NAME` varchar(12) NOT NULL,
  `PHONE` varchar(20) NOT NULL,
  PRIMARY KEY (`RID`),
  CONSTRAINT `ds_rider_ibfk_1` FOREIGN KEY (`RID`) REFERENCES `ds_account` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for ds_store
-- ----------------------------
DROP TABLE IF EXISTS `ds_store`;
CREATE TABLE `ds_store` (
  `SID` varchar(12) NOT NULL,
  `NAME` varchar(12) NOT NULL,
  `PHONE` varchar(20) NOT NULL,
  `ADRESS` varchar(30) NOT NULL,
  `STYPE` varchar(4) NOT NULL,
  PRIMARY KEY (`SID`),
  CONSTRAINT `ds_store_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `ds_account` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `OID` varchar(30) NOT NULL,
  `SID` varchar(12) NOT NULL,
  `CID` varchar(12) NOT NULL,
  `RID` varchar(12) DEFAULT NULL,
  `BILLINGTIME` varchar(30) DEFAULT NULL,
  `ACCEPTTIME` varchar(30) DEFAULT NULL,
  `FINISHTIME` varchar(30) DEFAULT NULL,
  `SALARY` varchar(12) DEFAULT NULL,
  `TOTALPRICE` varchar(12) DEFAULT NULL,
  `ISRTAKEN` varchar(12) DEFAULT NULL,
  `ISDELIVERY` varchar(12) DEFAULT NULL,
  `ISCONFIRM` varchar(12) DEFAULT NULL,
  `ISSTAKEN` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`OID`),
  KEY `SID` (`SID`),
  KEY `CID` (`CID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`SID`) REFERENCES `ds_store` (`SID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`CID`) REFERENCES `ds_customer` (`CID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Table structure for order_goods
-- ----------------------------
DROP TABLE IF EXISTS `order_goods`;
CREATE TABLE `order_goods` (
  `OID` varchar(30) NOT NULL,
  `NAME` varchar(12) NOT NULL,
  `PRICE` varchar(5) DEFAULT NULL,
  `NUM` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`OID`,`NAME`),
  CONSTRAINT `order_goods_ibfk_1` FOREIGN KEY (`OID`) REFERENCES `orders` (`OID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
