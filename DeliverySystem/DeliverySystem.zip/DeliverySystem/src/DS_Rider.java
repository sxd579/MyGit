import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DS_Rider {
    ArrayList<Order_Bean> order_beans = new ArrayList <Order_Bean>();
    int height;
    int num =0;
    JPanel panelTakeOrder;
    JPanel panelOrders;
    JScrollPane scrollPaneOrders;
    ArrayList<SingleRiderTakeOrder_Panel> singleRiderTakeOrder_panels = new ArrayList <SingleRiderTakeOrder_Panel>();
    public DS_Rider(String id){
        order_beans = Server_API.getAllOrders(order_beans);
        rider(id);
    }
    public  void rider(String id){
        JFrame frameRider = new JFrame("骑手:"+id);
        frameRider.setBounds(400,100,900,900);
        JPanel panelRider = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawLine(0, 110, 900, 110);
            }
        };
        panelRider.setBackground(new Color(252,230,201));
        panelRider.setLayout(null);
        JButton buttonRiderInfo = new JButton("个人信息");
        buttonRiderInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRiderInfo.setBackground(Color.cyan);
        buttonRiderInfo.setOpaque(false);
        buttonRiderInfo.setBounds(50,50,200,50);
        JButton buttonRiderOrders = new JButton("接单记录");
        buttonRiderOrders.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRiderOrders.setBackground(Color.cyan);
        buttonRiderOrders.setOpaque(false);
        buttonRiderOrders.setBounds(250,50,200,50);
        JButton buttonRiderSays = new JButton("评价记录");
        buttonRiderSays.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRiderSays.setBackground(Color.cyan);
        buttonRiderSays.setOpaque(false);
        buttonRiderSays.setBounds(450,50,200,50);
        JButton buttonRiderTakeRepaint = new JButton("刷新订单大厅");
        buttonRiderTakeRepaint.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRiderTakeRepaint.setBackground(Color.cyan);
        buttonRiderTakeRepaint.setBackground(Color.cyan);
        buttonRiderTakeRepaint.setOpaque(false);
        buttonRiderTakeRepaint.setBounds(650,50,200,50);

        panelTakeOrder = new JPanel();
        panelTakeOrder.setLayout(null);
        panelTakeOrder.setBounds(120,120,630,730);
        panelTakeOrder.setBackground(new Color(176,224,230));
        panelOrders = new JPanel();
        panelOrders.setLayout(null);
        panelOrders.setBackground(new Color(176,224,230));
        scrollPaneOrders = new JScrollPane(panelOrders);
        scrollPaneOrders.setBounds(10,20,580,680);
        height = 0;
        for (int i = 0;i<order_beans.size();i++){
                if ((!order_beans.get(i).isRTaken())&&(order_beans.get(i).isSTaken())) {
                    SingleRiderTakeOrder_Panel singleGood_store_panel =   new SingleRiderTakeOrder_Panel(
                            order_beans.get(i).getOid(),
                            order_beans.get(i).getCName(),
                            order_beans.get(i).getTotal_Price(),
                            order_beans.get(i).getCAdress(),
                            order_beans.get(i).getSalary(),
                            order_beans.get(i).isSTaken(),
                            order_beans.get(i).isRTaken(),
                            order_beans.get(i).isDelivery(),
                            order_beans.get(i).isConfirm(),
                            num,
                            order_beans.get(i).getSid(),
                            order_beans.get(i).getRid(),
                            order_beans.get(i),id);
                    panelOrders.add(singleGood_store_panel);
                    panelOrders.revalidate();
                    height += 270;
                    num ++;
                }

        }
        num = 0;
        panelOrders.setPreferredSize(new Dimension(scrollPaneOrders.getWidth(),height));



        panelTakeOrder.add(scrollPaneOrders);
        panelRider.add(panelTakeOrder);
        panelRider.add(buttonRiderInfo);
        panelRider.add(buttonRiderOrders);
        panelRider.add(buttonRiderSays);
        panelRider.add(buttonRiderTakeRepaint);
        frameRider.add(panelRider);
        frameRider.setVisible(true);
        frameRider.setResizable(false);
        buttonRiderInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Riderinfo(id);
            }
        });
        buttonRiderOrders.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Rider_Order(id);
            }
        });
        buttonRiderSays.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Evaluation_Rider(id);
            }
        });
        buttonRiderTakeRepaint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                order_beans = Server_API.getAllOrders(order_beans);
                panelTakeOrder.remove(scrollPaneOrders);
                panelTakeOrder.repaint();
                panelOrders = new JPanel();
                panelOrders.setLayout(null);
                panelOrders.setBackground(new Color(176,224,230));
                scrollPaneOrders = new JScrollPane(panelOrders);
                scrollPaneOrders.setBounds(10,20,580,680);
                singleRiderTakeOrder_panels.clear();
                height = 0;
                for (int i = 0;i<order_beans.size();i++){
                    if ((!order_beans.get(i).isRTaken())&&(order_beans.get(i).isSTaken())) {
                        SingleRiderTakeOrder_Panel singleGood_store_panel =   new SingleRiderTakeOrder_Panel(
                                order_beans.get(i).getOid(),
                                order_beans.get(i).getCName(),
                                order_beans.get(i).getTotal_Price(),
                                order_beans.get(i).getCAdress(),
                                order_beans.get(i).getSalary(),
                                order_beans.get(i).isSTaken(),
                                order_beans.get(i).isRTaken(),
                                order_beans.get(i).isDelivery(),
                                order_beans.get(i).isConfirm(),
                                num,
                                order_beans.get(i).getSid(),
                                order_beans.get(i).getRid(),
                                order_beans.get(i),id);
                        panelOrders.add(singleGood_store_panel);
                        panelOrders.revalidate();
                        height += 270;
                        num ++;
                    }

                }
                num = 0;
                panelOrders.setPreferredSize(new Dimension(scrollPaneOrders.getWidth(),height));

                panelTakeOrder.add(scrollPaneOrders);
                panelTakeOrder.repaint();



            }
        });
    }

    public static void main(String[] args) {
        new DS_Rider("");
    }
}
