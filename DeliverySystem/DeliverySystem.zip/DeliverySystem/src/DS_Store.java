import javax.imageio.plugins.jpeg.JPEGHuffmanTable;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.security.KeyPair;
import java.util.ArrayList;

public class DS_Store {
    ArrayList<Good_Bean> good_beans = new ArrayList <Good_Bean>();
    ArrayList<SingleGood_Store_Panel> singleGood_store_panels = new ArrayList <SingleGood_Store_Panel>();
    JPanel panelGood;
    JScrollPane scrollPaneGood;
    JPanel panelMenu;
    public DS_Store(String id){
        good_beans = Server_API.getAllGood(id);
        store(id);
    }
    public void  store(String id){
        JFrame frameStore = new JFrame("商家"+id);
        frameStore.setBounds(600,100,1000,900);
        JPanel panelStore = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawLine(0, 120, 1000, 120);
            }
        };
        panelStore.setBackground(new Color(252,230,201));
        panelStore.setLayout(null);
        JButton buttonInfo =new JButton("商家信息");
        buttonInfo.setBackground(Color.cyan);
        buttonInfo.setOpaque(false);
        buttonInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonInfo.setBounds(50,50,200,50);
        JButton buttonSay = new JButton("客户评价");
        buttonSay.setBackground(Color.cyan);
        buttonSay.setOpaque(false);
        buttonSay.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonSay.setBounds(250,50,200,50);
        JButton buttonOrder = new JButton("接单发单");
        buttonOrder.setBackground(Color.cyan);
        buttonOrder.setOpaque(false);
        buttonOrder.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonOrder.setBounds(450,50,200,50);
        JButton buttonUpdate = new JButton("刷新商品");
        buttonUpdate.setBackground(Color.cyan);
        buttonUpdate.setOpaque(false);
        buttonUpdate.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonUpdate.setBounds(650,50,200,50);


        JLabel labelTip  = new JLabel("已有商品");
        labelTip.setFont(new Font("微软雅黑", Font.BOLD, 20));
        labelTip.setBounds(30,140,200,50);
        panelMenu = new JPanel();
        panelMenu.setBackground(new Color(176,224,230));
        panelMenu.setLayout(null);
        panelMenu.setBounds(30,210,500,650);
        panelGood = new JPanel();
        panelGood.setLayout(null);
        panelGood.setBackground(new Color(176,224,230));
        scrollPaneGood = new JScrollPane(panelGood);
        scrollPaneGood.setBounds(0,0,500,650);
        int height  = 0;
        for (int i = 0;i<good_beans.size();i++){
            SingleGood_Store_Panel singleGood_store_panel = new SingleGood_Store_Panel(id,good_beans.get(i).getName(),good_beans.get(i).getIntro(),good_beans.get(i).getPrice(),good_beans.get(i),i);
            singleGood_store_panels.add(singleGood_store_panel);
            panelGood.add(singleGood_store_panel);
            panelGood.revalidate();
            height+=220;
        }
        panelGood.setPreferredSize(new Dimension(scrollPaneGood.getWidth(),height));


        //添加菜品
        JPanel panelAddGood = new JPanel();
        panelAddGood.setLayout(new GridLayout(4,1));
        panelAddGood.setBackground(new Color(176,224,230));
        panelAddGood.setBounds(600,310,300,400);
        JPanel panelName = new JPanel();
        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelName.setBackground(new Color(176,224,230));
        JPanel panelIntro = new JPanel();
        panelIntro.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelIntro.setBackground(new Color(176,224,230));
        JPanel panelCost = new JPanel();
        panelCost.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCost.setBackground(new Color(176,224,230));
        JPanel panelAdd = new JPanel();
        panelAdd.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelAdd.setBackground(new Color(176,224,230));
        JLabel labelName = new JLabel("商品名:");
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelIntro = new JLabel("简介:");
        labelIntro.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelCost = new JLabel("单价:￥");
        labelCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldName = new JTextField(8);
        textFieldName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldName.getText().length()>11){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        JTextField textFieldIntro = new JTextField(10);
        textFieldIntro.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldIntro.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldIntro.getText().length()>19){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        JTextField textFieldCost = new JTextField(5);
        textFieldCost.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldCost.getText().length()>4){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        textFieldCost.addKeyListener(Server_API.listenerOnlyNum);
        textFieldCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JButton buttonAdd = new JButton("添加菜品");
        buttonAdd.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonAdd.setBackground(new Color(176,224,230));
        buttonAdd.setOpaque(false);


        JButton buttonReduce = new JButton("删除菜品");
        buttonReduce.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonReduce.setBackground(new Color(176,224,230));
        buttonReduce.setOpaque(false);

        panelName.add(labelName);
        panelName.add(textFieldName);
        panelIntro.add(labelIntro);
        panelIntro.add(textFieldIntro);
        panelCost.add(labelCost);
        panelCost.add(textFieldCost);
        panelAdd.add(buttonAdd);
        panelAdd.add(buttonReduce);
        panelAddGood.add(panelName);
        panelAddGood.add(panelIntro);
        panelAddGood.add(panelCost);
        panelAddGood.add(panelAdd);

        //刷新商品列表
        buttonUpdate.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                scrollPaneGood  = new JScrollPane(new JPanel());
                good_beans = Server_API.getAllGood(id);
                panelMenu.remove(scrollPaneGood);
                panelMenu.repaint();
                panelGood = new JPanel();
                panelGood.setLayout(null);
                panelGood.setBackground(new Color(176,224,230));
                scrollPaneGood = new JScrollPane(panelGood);
                scrollPaneGood.setBounds(0,0,500,650);
                singleGood_store_panels.clear();
                int height  = 0;
                for (int i = 0;i<good_beans.size();i++){
                    SingleGood_Store_Panel singleGood_store_panel = new SingleGood_Store_Panel(id,good_beans.get(i).getName(),good_beans.get(i).getIntro(),good_beans.get(i).getPrice(),good_beans.get(i),i);
                    singleGood_store_panels.add(singleGood_store_panel);
                    panelGood.add(singleGood_store_panel);
                    panelGood.revalidate();
                    height+=220;
                }
                panelGood.setPreferredSize(new Dimension(scrollPaneGood.getWidth(),height));
                panelMenu.add(scrollPaneGood);
                panelMenu.repaint();
            }
        });
        buttonAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textFieldName.getText().equals("")||textFieldIntro.getText().equals("")||textFieldCost.getText().equals("")){
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">添加失败，请填写完整信息</font></h2></html>"),
                            "添加成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    if (Server_API.addGood(id, textFieldName.getText(), textFieldIntro.getText(), textFieldCost.getText())) {
                        JOptionPane.showMessageDialog(null,
                                new JLabel("<html><h2><font color='red'><font size=\"25\">添加成功</font></h2></html>"),
                                "添加成功",
                                JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null,
                                new JLabel("<html><h2><font color='red'><font size=\"25\">添加失败，已有同名菜品</font></h2></html>"),
                                "添加成功",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }
        });
        buttonReduce.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (Server_API.deleteGood(id, textFieldName.getText())) {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">删除成功</font></h2></html>"),
                            "删除成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">删除失败，没有该菜品</font></h2></html>"),
                            "删除成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        buttonInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Storeinfo(id);
            }
        });
        buttonSay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Evaluation_Store(id);
            }
        });
        buttonOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new DS_Store_Order(id);
            }
        });
        panelMenu.add(scrollPaneGood);
        panelStore.add(panelMenu);
        panelStore.add(panelAddGood);
        panelStore.add(buttonInfo);
        panelStore.add(buttonSay);
        panelStore.add(buttonOrder);
        panelStore.add(buttonUpdate);
        panelStore.add(labelTip);
        frameStore.add(panelStore);
        frameStore.setVisible(true);
        frameStore.setResizable(false);

    }

    public static void main(String[] args) {
        new DS_Store("s10000");
    }
}
