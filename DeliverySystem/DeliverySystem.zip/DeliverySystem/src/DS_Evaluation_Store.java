import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DS_Evaluation_Store {
    ArrayList<Evaluation_Bean> evaluation_beans = new ArrayList <Evaluation_Bean>();
    public DS_Evaluation_Store(String sid){
        evaluation_beans = Server_API.getStoreEvaluationBeans(sid);
        evaluationstore(sid);
    }
    public void evaluationstore(String  id){
        JFrame frameEva = new JFrame("客户评价");
        frameEva.setBounds(700,200,600,750);
        JPanel panelEva = new JPanel();
        panelEva.setBackground(new Color(176,224,230));
        panelEva.setLayout(null);
        JLabel labelTip  = new JLabel("客户评价");
        labelTip.setFont(new Font("微软雅黑", Font.BOLD, 20));
        labelTip.setBounds(20,20,200,50);
        //评价

        JPanel panelEvaluation = new JPanel();
        panelEvaluation.setLayout(null);
        panelEvaluation.setBounds(20,70,500,600);
        panelEvaluation.setBackground(Color.white);

        JPanel panelEvaluate = new JPanel();
        panelEvaluate.setLayout(null);
        panelEvaluate.setBackground(Color.white);
        JScrollPane scrollPaneEvaluation = new JScrollPane(panelEvaluate);
        scrollPaneEvaluation.setBounds(0,0,500,600);
        int height1 = 0;
        for (int i = 0;i<evaluation_beans.size();i++){
            panelEvaluate.add(new SingleClientSay_Store_Panel(evaluation_beans.get(i).getCname(),evaluation_beans.get(i).getContent(),evaluation_beans.get(i).getLevel(),evaluation_beans.get(i).getTime(),evaluation_beans.get(i).getReply(),evaluation_beans.get(i).getCid(),id,i));
            panelEvaluate.revalidate();
            height1 +=220;
        }
//        for (int i = 0;i<storeEvaluations.size();i++){
//            panelEvaluate.add(new SingleClientSay_Panel(storeEvaluationsNames.get(i),storeEvaluations.get(i),storeEvaluationsLevel.get(i),storeEvaluationsTime.get(i),i));
//            panelEvaluate.revalidate();
//            height1 +=220;
//        }
        panelEvaluate.setPreferredSize(new Dimension(scrollPaneEvaluation.getWidth(),height1));
        panelEvaluation.add(scrollPaneEvaluation);


        panelEva.add(labelTip);
        panelEva.add(panelEvaluation);
        frameEva.add(panelEva);
        frameEva.setVisible(true);
        frameEva.setResizable(false);

    }

    public static void main(String[] args) {
        new DS_Evaluation_Store("");
    }
}
