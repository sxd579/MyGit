import javax.swing.*;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class DS_Customer {
    static ArrayList<MyTreeNode> myTreeNodes = new ArrayList <MyTreeNode>();
    static ArrayList<MyTreeNode> allTreeNodes = new ArrayList <MyTreeNode>();
    public DS_Customer(String id){

        //生成商家树
        myTreeNodes = Server_API.buildTree();
        allTreeNodes = Server_API.buildTree();
        customer(id);
    }
    public void customer(String id){
        JFrame frameCustomer = new JFrame("顾客："+id);
        frameCustomer.setBounds(400,100,1200,800);
        frameCustomer.setResizable(false);

        JPanel panelCustomer = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawLine(0, 140, 1200, 140);
            }
        };
        panelCustomer.setBackground(new Color(252,230,201));
        panelCustomer.setLayout(null);



        //个人
        JButton buttonInfo = new JButton("个人信息");
        buttonInfo.setBackground(Color.cyan);
        buttonInfo.setOpaque(false);
        buttonInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DS_Customerinfo ds_customerinfo = new DS_Customerinfo(id) ;
            }
        });
        buttonInfo.setBounds(50,60,200,50);



        //订单
        JButton buttonOrder = new JButton("订单信息");
        buttonOrder.setBackground(Color.cyan);
        buttonOrder.setOpaque(false);
        buttonOrder.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               DS_Customer_Order ds_orderinfo = new DS_Customer_Order(id);
            }
        });
        buttonOrder.setBounds(250,60,200,50);
        JPanel panelStores = new JPanel();
        panelStores.setLayout(new BorderLayout());
        panelStores.setBounds(50,150,500,600);
        JPanel panelTree = new JPanel();
        panelTree.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelTree.setBackground(new Color(176,224,230));
        JScrollPane jScrollPane = new JScrollPane(panelTree);
        panelStores.add(jScrollPane);
        JTree storesTree;


        ///////////测试代码
        MyTreeNode root = new MyTreeNode("根节点", true);
        MyTreeNode nodeAll = new MyTreeNode("全部",true);
        MyTreeNode nodeT = new MyTreeNode("甜品饮品",true);
        MyTreeNode nodeS = new MyTreeNode("速食简餐",true);
        MyTreeNode nodeM = new MyTreeNode("米粉面馆",true);
        MyTreeNode nodeZ = new MyTreeNode("炸鸡汉堡",true);
        MyTreeNode nodeB = new MyTreeNode("包子粥店",true);
        MyTreeNode nodeG = new MyTreeNode("水果生鲜",true);
        MyTreeNode nodeC = new MyTreeNode("超市便利",true);

        for (int i = 0 ;i<myTreeNodes.size();i++){
            nodeAll.add(allTreeNodes.get(i));
            if (myTreeNodes.get(i).getType().equals("甜品饮品") ){
                nodeT.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("速食简餐") ){
                nodeS.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("米粉面馆") ){
                nodeM.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("炸鸡汉堡") ){
                nodeZ.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("包子粥店") ){
                nodeB.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("超市便利") ){
                nodeC.add(myTreeNodes.get(i));
            }
            if (myTreeNodes.get(i).getType().equals("水果生鲜") ){
                nodeG.add(myTreeNodes.get(i));
            }
        }

        root.add(nodeAll);
        root.add(nodeT);
        root.add(nodeS);
        root.add(nodeM);
        root.add(nodeG);
        root.add(nodeT);
        root.add(nodeZ);
        root.add(nodeB);
        root.add(nodeC);


///////////



        DefaultTreeModel jmode = new DefaultTreeModel(root,true);
        storesTree = new JTree(jmode);
        storesTree.setBackground(new Color(176,224,230));
        DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) storesTree.getCellRenderer();
        renderer.setOpenIcon(Config.openImg);
        renderer.setClosedIcon(Config.closeImg);
        renderer.setLeafIcon(Config.leafImg);

        storesTree.setFont(new Font(Font.SANS_SERIF, Font.LAYOUT_LEFT_TO_RIGHT, 20));
        storesTree.setRowHeight(50);//行高
        storesTree.setToggleClickCount(1);//点击一次给出响应
        storesTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);//设置一次只能选中一个节点
        storesTree.setRootVisible(false);//设置根节点不可见
        storesTree.putClientProperty("JTree.lineStyle", "None");//设置线条隐藏
        panelTree.add(storesTree);


        //商家信息
        JPanel panelMenu = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawLine(2, 0, 2, 600);
            }
        };
        panelMenu.setBounds(600,150,500,600);
        panelMenu.setBackground(new Color(176,224,230));
        CardLayout c = new CardLayout();
        panelMenu.setLayout(c);
        JPanel panelDefault = new JPanel();
        panelDefault.setLayout(null);
        panelDefault.setBackground(new Color(176,224,230));
        panelDefault.setOpaque(false);
        JLabel labelWelcome1 = new JLabel("亲爱的顾客，欢迎您！");
        labelWelcome1.setFont(new Font("微软雅黑", Font.BOLD, 25));
        labelWelcome1.setBounds(100,50,400,300);
        JLabel labelWelcome2 = new JLabel("请选择商家，选购商品。");
        labelWelcome2.setFont(new Font("微软雅黑", Font.BOLD, 25));
        labelWelcome2.setBounds(240,100,400,300);
        panelDefault.add(labelWelcome1);
        panelDefault.add(labelWelcome2);
        panelMenu.add(panelDefault,"1");


        MouseListener listenerTree = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    MyTreeNode selectionNode = (MyTreeNode) storesTree.getLastSelectedPathComponent();
                    if (selectionNode.isLeaf() && selectionNode.getLevel() == 2) {
                        System.out.println(selectionNode. getInfo());
                        Server_API.improveTreeNode(selectionNode.getId(),selectionNode);
                        panelMenu.add(new DS_Menu_Card(
                                selectionNode.getInfo(),
                                selectionNode.getGoodname(),
                                selectionNode.getUnitCost(),
                                selectionNode.getGoodIntros(),
                                selectionNode.getStoreEvaluations(),
                                selectionNode.getStoreEvaluationsNames(),
                                selectionNode.getStoreEvaluationsLevel(),
                                selectionNode.getStoreEvaluationsTime(),
                                selectionNode.getStoreEvaluationsReply(), selectionNode.getId(),id),
                                "2");
                        c.show(panelMenu,"2");
                    }
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        };

        storesTree.addMouseListener(listenerTree);


         panelCustomer.add(buttonInfo);
         panelCustomer.add(buttonOrder);
         panelCustomer.add(panelStores);
         panelCustomer.add(panelMenu);
        frameCustomer.add(panelCustomer);
        frameCustomer.setVisible(true);
    }

    public static void main(String[] args) {
        DS_Customer ds_customer = new DS_Customer("");
    }
}

