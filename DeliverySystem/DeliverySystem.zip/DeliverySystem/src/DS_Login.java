import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DS_Login {
    public DS_Login(){
        login();
    }
    static KeyListener listenerOnlyNum = new KeyListener() {

        @Override
        public void keyTyped(KeyEvent e) {
            int keyChar = e.getKeyChar();
            if (keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9) {

            } else {
                e.consume();//关键，屏蔽掉非法输入  
            }
        };

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    };
    //登入界面
    public static void login(){
        JFrame framelogin = new JFrame("送餐系统");
        framelogin.setBounds(750, 350, 450, 300);
        framelogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        framelogin.setResizable(false);

        JPanel panelLogin = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(Config.login.getImage(), 0, 0, null);
            }
        };
        panelLogin.setLayout(null);
        panelLogin.setBackground(new Color(252,230,201));
        framelogin.add(panelLogin);
        JPanel panelUser = new JPanel();
        JPanel panelPassword = new JPanel();
        JPanel panelBt = new JPanel();
        JLabel labelUser = new JLabel("账号:");
        JLabel labelPassword = new JLabel("密码:");
        JTextField textFieldUser = new JTextField(15);
        JPasswordField passwordField = new JPasswordField(15);
        passwordField.setEchoChar('*');
        JButton buttonLogin = new JButton("登入");
        buttonLogin.setMnemonic(KeyEvent.VK_ENTER);
        buttonLogin.setBackground(Color.cyan);
        JButton buttonRegister = new JButton("注册账号");
        buttonRegister.setBackground(Color.cyan);
        panelLogin.setLayout(null);
        panelUser.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelUser.setOpaque(false);
        panelUser.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelPassword.setOpaque(false);
        panelPassword.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelUser.setBounds(0, 111, 450, 50);
        panelPassword.setBounds(0, 161, 450, 50);
        panelBt.setBounds(0, 210, 450, 50);
        labelUser.setFont(new Font("微软雅黑", Font.BOLD, 20));
        labelPassword.setFont(new Font("微软雅黑", Font.BOLD, 20));

        textFieldUser.setFont(new Font("微软雅黑", Font.PLAIN, 20));
        textFieldUser.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldUser.getText().length()>8){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        passwordField.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (String.valueOf(passwordField.getPassword()).length()>11){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        passwordField.setFont(new Font("微软雅黑", Font.PLAIN, 20));
        buttonLogin.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRegister.setFont(new Font("微软雅黑", Font.BOLD, 20));
        panelLogin.add(panelPassword);
        panelLogin.add(panelUser);
        panelLogin.add(panelBt);
        panelUser.add(labelUser);
        panelUser.add(textFieldUser);
        panelPassword.add(labelPassword);
        panelPassword.add(passwordField);
        panelBt.add(buttonLogin);
        panelBt.add(buttonRegister);
        textFieldUser.setText("r10000");
        passwordField.setText("123123");
        framelogin.setVisible(true);
        buttonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {

                    if (String.valueOf(textFieldUser.getText()).equals("") || String.valueOf(passwordField.getPassword()).equals("")) {
                        JOptionPane.showMessageDialog(null,
                                new JLabel("<html><h2><font color='red'><font size=\"25\"> 输入账号密码为空，请重新输入</font></h2></html>"),
                                "逗我玩？",
                                JOptionPane.ERROR_MESSAGE);

                    }
                    else {

                        String type = Server_API.enter(textFieldUser.getText(),String.valueOf(passwordField.getPassword()));
                        System.out.println(type);
                        if (type.equals("顾客")) {

                            JOptionPane.showMessageDialog(null,
                                    new JLabel("<html><h2><font color='red'><font size=\"25\"> 欢迎您,用户:"+textFieldUser.getText()+"!</font></h2></html>"),
                                    "登入成功",
                                    JOptionPane.INFORMATION_MESSAGE);
                            new DS_Customer(textFieldUser.getText());
                            framelogin.dispose();
                        }
                       else if (type.equals("骑手")) {

                            JOptionPane.showMessageDialog(null,
                                    new JLabel("<html><h2><font color='red'><font size=\"25\"> 欢迎您,用户:"+textFieldUser.getText()+"!</font></h2></html>"),
                                    "登入成功",
                                    JOptionPane.INFORMATION_MESSAGE);
                            new DS_Rider(textFieldUser.getText());
                            framelogin.dispose();
                        }
                        else if (type.equals( "商家")) {

                            JOptionPane.showMessageDialog(null,
                                    new JLabel("<html><h2><font color='red'><font size=\"25\"> 欢迎您,用户:"+textFieldUser.getText()+"!</font></h2></html>"),
                                    "登入成功",
                                    JOptionPane.INFORMATION_MESSAGE);
                            new DS_Store(textFieldUser.getText());
                            framelogin.dispose();
                        }
                        else
                        {

                            JOptionPane.showMessageDialog(null,
                                    new JLabel("<html><h2><font color='red'><font size=\"25\"> 输入账号密码错误，请重新输入</font></h2></html>"),
                                    "消息",
                                    JOptionPane.ERROR_MESSAGE);
                            passwordField.setText("");

                        }
                    }

                }catch(Exception e0){
                    e0.printStackTrace();
                }
            }
        });
        buttonRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DS_Register register = new DS_Register();
            }
        });
    }
}
