import sun.security.krb5.internal.tools.Ktab;

import javax.swing.*;
import java.awt.*;

public class SingleClientSay_Panel extends JPanel{
    public SingleClientSay_Panel(String name,String content,String level,String time,String reply,int num){
        JTextField textFieldR = new JTextField();
        if (reply.length()==0){
            reply = "尚未回复";
            textFieldR.setForeground(Color.gray);
        }
        else {
            textFieldR.setForeground(Color.red);
        }
        this.setBackground(Color.white);
        JPanel panelNLTR = new JPanel();
        panelNLTR.setBackground(Color.white);
        panelNLTR.setLayout(new GridLayout(5,1));
        JLabel labelN = new JLabel(name);
        labelN.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelL = new JLabel(level);
        labelL.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelT = new JLabel(time);
        labelT.setFont(new Font("微软雅黑", Font.BOLD, 20));

        JPanel panelC = new JPanel();
        panelC.setOpaque(false);
        panelC.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelC = new JLabel("顾客评价:");
        labelC.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldC = new JTextField(content);
        textFieldC.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldC.setEditable(false);
        textFieldC.setBackground(Color.cyan);
        panelC.add(labelC);
        panelC.add(textFieldC);

        JPanel panelR = new JPanel();
        panelR.setOpaque(false);
        panelR.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelR = new JLabel("商家回复:");
        labelR.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldR.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldR.setEditable(false);
        textFieldR.setBackground(Color.cyan);
        textFieldR.setText(reply);
        panelR.add(labelR);
        panelR.add(textFieldR);

        panelNLTR.add(labelN);
        panelNLTR.add(labelT);
        panelNLTR.add(labelL);
        panelNLTR.add(panelC);
        panelNLTR.add(panelR);



        this.setLayout(new BorderLayout());
        this.setBounds(20,20+270*num,400,250);
        this.add("North",panelNLTR);



    }
    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,250);
        frameTest.add(new SingleClientSay_Panel("sxd","味道还是一如既往的好，价格实惠","*****","2019年8月22日15:15:08","123456",0));
        frameTest.setVisible(true);
    }
}
