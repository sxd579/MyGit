import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class SingleClientSay_Store_Panel extends JPanel {
    int number;
    public SingleClientSay_Store_Panel(String name,String content,String level,String time,String reply,String cid,String sid,int num){
        number  = num;
        JPanel panelNLT = new JPanel();
        this.setBackground(new Color(176,224,230));
        panelNLT.setBackground(new Color(176,224,230));
        panelNLT.setLayout(new GridLayout(3,1));
        JLabel labelN = new JLabel(name);
        labelN.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelL = new JLabel(level);
        labelL.setFont(new Font("微软雅黑", Font.BOLD, 15));
        JLabel labelT = new JLabel(time);
        labelT.setFont(new Font("微软雅黑", Font.BOLD, 15));
        panelNLT.add(labelN);
        panelNLT.add(labelT);
        panelNLT.add(labelL);

        JLabel labelC = new JLabel(content);
        labelC.setFont(new Font("微软雅黑", Font.BOLD, 15));

        JPanel panelRelpy = new JPanel();
        panelRelpy.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelR = new JLabel("商家回复:"+reply);
        labelR.setFont(new Font("微软雅黑", Font.BOLD, 15));
        labelR.setForeground(Color.gray);

        JTextField textFieldR = new JTextField(20);
        textFieldR.setFont(new Font("微软雅黑", Font.BOLD, 15));
        textFieldR.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldR.getText().length()>29){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        JButton buttonReply = new JButton("回复");
        buttonReply.setFont(new Font("微软雅黑", Font.BOLD, 15));
        buttonReply.setBackground(Color.cyan);
        buttonReply.setOpaque(false);

        if (reply.length()==0){
            panelRelpy.add(textFieldR);
            panelRelpy.add(buttonReply);
        }
        else {
            panelRelpy.add(labelR);
        }

        buttonReply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textFieldR.getText().length()!=0) {
                    Server_API.replyStoreEvaluationBeans(sid, cid, time, textFieldR.getText());
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">回复成功</font></h2></html>"),
                            "回复成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'>回复失败<font size=\"25\"></font></h2></html>"),
                            "回复失败",
                            JOptionPane.ERROR_MESSAGE);
                }


            }
        });
        this.setLayout(new BorderLayout());
        this.setBounds(20,20+220*num,400,200);
        this.add("North",panelNLT);
        this.add("Center",labelC);
        this.add("South",panelRelpy);



    }
    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,200);
//        frameTest.add(new SingleClientSay_Store_Panel("sxd","味道还是一如既往的好，价格实惠","*****","2019年8月22日15:15:08","",0));
        frameTest.setVisible(true);
    }
}
