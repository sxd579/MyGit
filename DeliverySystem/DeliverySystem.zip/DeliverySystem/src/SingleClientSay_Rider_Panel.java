import javax.swing.*;
import java.awt.*;

public class SingleClientSay_Rider_Panel extends JPanel {
    public SingleClientSay_Rider_Panel(String name,String content,String level,String time,int num){
        JPanel panelNLTR = new JPanel();
        this.setBackground(new Color(176,224,230));
        panelNLTR.setBackground(new Color(176,224,230));
        panelNLTR.setLayout(new GridLayout(4,1));
        JLabel labelN = new JLabel(name);
        labelN.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelL = new JLabel(level);
        labelL.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelT = new JLabel(time);
        labelT.setFont(new Font("微软雅黑", Font.BOLD, 20));
        panelNLTR.add(labelN);
        panelNLTR.add(labelT);
        panelNLTR.add(labelL);

        JTextField textFieldC = new JTextField(content);
        textFieldC.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldC.setEditable(false);

        panelNLTR.add(textFieldC);
        this.setLayout(new BorderLayout());
        this.setBounds(20,20+180*num,400,160);
        this.add("North",panelNLTR);




    }
    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,200);
        frameTest.add(new SingleClientSay_Rider_Panel("sxd","味道还是一如既往的好，价格实惠","*****","2019年8月22日15:15:08",0));
        frameTest.setVisible(true);
    }
}
