
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Server_API {
    //全局自增数
    private static int count = 0;
    //每秒生成的订单上限
    private static final int total = 9999;
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy/MM/dd HH-mm-ss");
    // 记录上一次的时间，用来判断是否需要递增全局数
    private static String now = null;
    public static String getDateStr(){
        //用于订单号
        return sdf.format(new Date());
    }
    public static String getNowDateStr(){
        //记录订单时间
        return sdfNow.format(new Date());
    }
    //生成订单号
    public static String getOrderNum(){
        String datastr = getDateStr();
        if (datastr.equals(now)) {
            count++;// 自增
        } else {
            count = 1;
            now = datastr;
        }
        int countInteger = String.valueOf(total).length() - String.valueOf(count).length();// 算补位
        String bu = "";// 补字符串
        for (int i = 0; i < countInteger; i++) {
            bu += "0";
        }
        bu += String.valueOf(count);
        if (count >= total) {
            count = 0;
            System.out.println("订单上限过小");
        }
        return datastr + bu;
    }

    //登入账号
    public  static String enter(String id ,String psw){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_account where id = '"+id+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                if (psw.equals(rs.getString(2)))
                {
                    System.out.println("用户:"+id+"登入成功!");
                    System.out.println(rs.getString(3));
                    return rs.getString(3);
                }
            }
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("用户:"+id);

        return  "登入失败";
    }
    //注册账号
    public static String register(String name,String phoneNumber,String psw,String type){
        int account = 10000;
        String accountType = "";
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql,sql0="";
            sql = "select * from ds_account where type = '"+type+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                account++;
            }
            if (type =="顾客"){
                accountType = "c"+account;
                sql0 = "insert into ds_customer values ('"
                        +accountType
                        + "','"+name
                        +"','"+phoneNumber
                        +"','"+"尚未填写"
                        +"')";
            }
            if (type =="骑手"){
                accountType = "r"+account;
                sql0 = "insert into ds_rider values ('"
                        +accountType
                        + "','"+name
                        +"','"+phoneNumber
                        +"')";
            }
            if (type =="商家"){
                accountType = "s"+account;
                sql0 = "insert into ds_store values ('"
                        +accountType
                        + "','"+name
                        +"','"+phoneNumber
                        +"','"+"尚未填写"
                        +"','"+"尚未填写"
                        +"')";

            }
//                // 完成后关闭
            sql = "insert into ds_account values ('"
                    +accountType
                    + "','"+psw
                    +"','"+type
                    +"')";
            stmt.execute(sql);
            stmt.execute(sql0);

            rs.close();
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("注册完成!");
        return accountType;
    }

    //添加商品
    public static boolean addGood(String sid , String name ,String intro, String price ){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_good  where sid = '"+sid+"' and name = '"+name+"'";
            ResultSet rs = stmt.executeQuery(sql);
            if (!rs.next()) {
                sql = "insert into ds_good values ('"
                        + sid
                        + "','" + intro
                        + "','" + price
                        + "','" + name
                        + "')";
                stmt.execute(sql);
                return  true;
            }

            stmt.close();
            conn.close();
            return  false;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("给账号:"+sid+" 添加商品:"+name+"成功!");
        return false;

    }
    //删除商品
    public static boolean deleteGood(String sid , String name){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_good  where sid = '"+sid+"' and name = '"+name+"'";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                sql = "delete from ds_good where sid = '"+sid+"' and name = '"+name+"'";
                stmt.execute(sql);
                return  true;
            }

            stmt.close();
            conn.close();
            return  false;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("给账号:"+sid+"删除商品:"+name+"成功!");
        return false;

    }
    //修改商品
    public static boolean updateGood( String name,String intro, String price,Good_Bean good_bean){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update ds_good set " +
                        "name = '"+name+"',"+
                        "intro = '"+intro+"',"+
                        "price = '"+price+"'"+
                        " where sid = '"+good_bean.getSid()+"' and name = '"+good_bean.getName()+"'";
            stmt.execute(sql);
            stmt.close();
            conn.close();
            return true ;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("给账号:"+good_bean.getSid()+"修改商品:"+good_bean.getName()+"成功!");
        return false;

    }
    //获得商家商品列表
    public static ArrayList<Good_Bean> getAllGood(String sid){
        ArrayList<Good_Bean> good_beans = new ArrayList <Good_Bean>();
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_good  where sid = '"+sid+"'";
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                Good_Bean good_bean = new Good_Bean();
                good_bean.setSid(sid);
                good_bean.setPrice(rs.getString(3));
                good_bean.setName(rs.getString(4));
                good_bean.setIntro(rs.getString(2));
                good_beans.add(good_bean);
            }


            stmt.close();
            conn.close();
            return  good_beans;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("给账号:"+sid+"初始化商品列表成功!");
        return good_beans;

    }

    //评价商家，骑手
    public static boolean evaluate(String cid,String rid ,String sid, String name ,String contentR, String levelR,String time,String contentS,String levelS){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql="";
            sql = "insert into ds_evaluation_rider values ('"
                    +rid
                    +"','"+name
                    +"','"+contentR
                    +"','"+levelR
                    +"','"+time
                    +"','"+cid
                    +"')";
            stmt.execute(sql);
            sql = "insert into ds_evaluation_store values ('"
                    +sid
                    +"','"+name
                    +"','"+contentS
                    +"','"+levelS
                    +"','"+time
                    +"','"
                    +"','"+cid
                    +"')";
            stmt.execute(sql);
            stmt.close();
            conn.close();
            return true;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("给账号:"+sid+cid+" 评价成功!");
        return false;
    }

    //生成订单
    public static  void buildOrder(String oid,
                                   String sid,
                                   String cid,
                                   String rid,
                                   String billingTime,
                                   String acceptTime,
                                   String finishTime,
                                   String salary,
                                   String totalPrice,
                                   boolean isSTaken,
                                   boolean isRTaken,
                                   boolean isDelivery,
                                   boolean isConfirm,
                                   ArrayList<SingleGood_Panel> singleGood_panels){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询

            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql="";
            sql = "insert into orders values ('"
                    +oid
                    +"','"+sid
                    +"','"+cid
                    +"','"+rid
                    +"','"+billingTime
                    +"','"+acceptTime
                    +"','"+finishTime
                    +"','"+salary
                    +"','"+totalPrice
                    +"','"+isRTaken
                    +"','"+isDelivery
                    +"','"+isConfirm
                    +"','"+isSTaken
                    +"')";
            stmt.execute(sql);
            for (int i = 0;i<singleGood_panels.size();i++){
                System.out.println(singleGood_panels.get(i).odNums);
                if (singleGood_panels.get(i).odNums>0){
                    System.out.println(2);
                    sql ="insert into order_goods values ('"
                            +oid
                            +"','"+singleGood_panels.get(i).name
                            +"','"+singleGood_panels.get(i).price
                            +"','"+singleGood_panels.get(i).odNums
                            +"')";
                    stmt.execute(sql);
                }
            }

            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("下单成功:"+oid);


    }

    //查询商家信息
    public  static String[] getStoreInfo(String sid){
        String [] storeInfos = new String[4];
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_store where sid = '"+sid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                storeInfos[0] = rs.getString(2);
                storeInfos[1] = rs.getString(3);
                storeInfos[2] = rs.getString(4);
                storeInfos[3] = rs.getString(5);
                return  storeInfos;
            }
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("商家:"+sid);

        return  null;
    }
    //修改商家信息
    public  static boolean changeStoreInfo(String sid,String [] storeInfos){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update ds_store set " +
                    "name = '"+storeInfos[0]+"',"+
                    "phone = '"+storeInfos[1]+"',"+
                    "adress = '"+storeInfos[2]+"',"+
                    "stype = '"+storeInfos[3]+"'"+
                    " where sid = '"+sid+"'";

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("用户:"+sid+"修改成功");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("用户:+"+sid+"修改失败");

        return  false;
    }

    //查询骑手信息
    public  static String[] getRiderInfo(String rid){
        String [] riderInfos = new String[2];
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_rider where rid = '"+rid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                riderInfos[0] = rs.getString(2);
                riderInfos[1] = rs.getString(3);
                return  riderInfos;
            }
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("骑手:"+rid);

        return  null;
    }
    //修改骑手信息
    public  static boolean changeRiderInfo(String rid,String [] riderInfos){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update ds_rider set " +
                    "name = '"+riderInfos[0]+"',"+
                    "phone = '"+riderInfos[1]+"'"+
                    " where rid = '"+rid+"'";

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("用户:"+rid+"修改成功");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("用户:+"+rid+"修改失败");

        return  false;
    }

    //查询顾客信息
    public  static String[] getCustomerInfo(String cid){
        String [] customerInfos = new String[3];
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_customer where cid = '"+cid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                customerInfos[0] = rs.getString(2);
                customerInfos[1] = rs.getString(3);
                customerInfos[2] = rs.getString(4);
                return  customerInfos;
            }
            stmt.close();
            conn.close();
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("顾客:"+cid);

        return  null;
    }

    //修改顾客信息
    public  static boolean changeCustomerInfo(String cid,String [] customerInfos){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update ds_customer set " +
                    "name = '"+customerInfos[0]+"',"+
                    "phone = '"+customerInfos[1]+"',"+
                    "adress = '"+customerInfos[2]+"'"+
                    " where cid = '"+cid+"'";

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("用户:"+cid+"修改成功");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("用户:+"+cid+"修改失败");

        return  false;
    }

     // 商家树生成
    public static ArrayList<MyTreeNode> buildTree(){
        ArrayList<MyTreeNode> storeTreeNodes = new ArrayList <MyTreeNode>();
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_store ";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                MyTreeNode storeTreeNode = new MyTreeNode(rs.getString(2),false);
                storeTreeNode.setId(rs.getString(1));
                storeTreeNode.setType(rs.getString(5));
                storeTreeNodes.add(storeTreeNode);
            }

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("商家树生成成功");
            return  storeTreeNodes;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return null;
    }

    //获取节点信息
    public static boolean improveTreeNode(String sid,MyTreeNode myTreeNode){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            System.out.println(sid);
            sql = "select * from ds_good where sid = '"+sid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                System.out.println(333);
                System.out.println(rs.getString(3));
                System.out.println(rs.getString(4));
                System.out.println(rs.getString(2));
                myTreeNode.getGoodname().add(rs.getString(4));
                myTreeNode.getGoodIntros().add(rs.getString(2));
                myTreeNode.getUnitCost().add(rs.getString(3));
            }
            sql = "select * from ds_evaluation_store where sid = '"+sid+"'";
            rs = stmt.executeQuery(sql);
            while(rs.next()){
                System.out.println(444);
                myTreeNode.getStoreEvaluations().add(rs.getString(3));
                myTreeNode.getStoreEvaluationsNames().add(rs.getString(2));
                myTreeNode.getStoreEvaluationsLevel().add(rs.getString(4));
                myTreeNode.getStoreEvaluationsTime().add(rs.getString(5));
                myTreeNode.getStoreEvaluationsReply().add(rs.getString(6));
            }
            stmt.close();
            conn.close();
            System.out.println("节点信息");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return false;

    }

    //获取顾客订单信息
    public static ArrayList<Order_Bean> getCustomerOrders(String cid){
        ArrayList<Order_Bean> order_beans = new ArrayList <>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            stmtName = conn.createStatement();
            String sql;
            System.out.println("顾客:"+cid);
            sql = "select * from orders where cid = '"+cid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                System.out.println(1);
                Order_Bean order_bean = new Order_Bean();
                order_bean.setOid(rs.getString(1));
                order_bean.setSid(rs.getString(2));
                order_bean.setCid(rs.getString(3));
                order_bean.setRid(rs.getString(4));
                order_bean.setBillingTime(rs.getString(5));
                order_bean.setAcceptTime(rs.getString(6));
                order_bean.setFinishTime(rs.getString(7));
                order_bean.setSalary(rs.getString(8));
                order_bean.setTotal_Price(rs.getString(9));
                order_bean.setRTaken( Boolean.parseBoolean(rs.getString(10)));
                order_bean.setDelivery(Boolean.parseBoolean(rs.getString(11)));
                order_bean.setConfirm(Boolean.parseBoolean(rs.getString(12)));
                order_bean.setSTaken(Boolean.parseBoolean(rs.getString(13)));
                String sqlN = "select name,phone from ds_rider where rid = '"+order_bean.getRid()+"'";
                ResultSet rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setRName(rsName.getString(1));
                    order_bean.setRPhone(rsName.getString(2));
                }
                sqlN = "select name,phone,adress from ds_store where sid = '"+order_bean.getSid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setSName(rsName.getString(1));
                    order_bean.setSPhone(rsName.getString(2));
                    order_bean.setSAdress(rsName.getString(3));
                }
                sqlN = "select name,phone,adress from ds_customer where cid = '"+order_bean.getCid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setCName(rsName.getString(1));
                    order_bean.setCPhone(rsName.getString(2));
                    order_bean.setCAdress(rsName.getString(3));
                }

                order_beans.add(order_bean);
            }
            stmt.close();
            conn.close();
            System.out.println("用户:"+cid+ "的订单信息");
            return  order_beans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }

        return order_beans;

    }
    //获取商家订单信息
    public static ArrayList<Order_Bean> getStoreOrders(String sid){
        ArrayList<Order_Bean> order_beans = new ArrayList <>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            stmtName = conn.createStatement();
            String sql;
            sql = "select * from orders where sid = '"+sid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                Order_Bean order_bean = new Order_Bean();
                order_bean.setOid(rs.getString(1));
                order_bean.setSid(rs.getString(2));
                order_bean.setCid(rs.getString(3));
                order_bean.setRid(rs.getString(4));
                order_bean.setBillingTime(rs.getString(5));
                order_bean.setAcceptTime(rs.getString(6));
                order_bean.setFinishTime(rs.getString(7));
                order_bean.setSalary(rs.getString(8));
                order_bean.setTotal_Price(rs.getString(9));
                order_bean.setRTaken( Boolean.parseBoolean(rs.getString(10)));
                order_bean.setDelivery(Boolean.parseBoolean(rs.getString(11)));
                order_bean.setConfirm(Boolean.parseBoolean(rs.getString(12)));
                order_bean.setSTaken(Boolean.parseBoolean(rs.getString(13)));
                String sqlN = "select name,phone from ds_rider where rid = '"+order_bean.getRid()+"'";
                ResultSet rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setRName(rsName.getString(1));
                    order_bean.setRPhone(rsName.getString(2));
                }
                sqlN = "select name,phone,adress from ds_store where sid = '"+order_bean.getSid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setSName(rsName.getString(1));
                    order_bean.setSPhone(rsName.getString(2));
                    order_bean.setSAdress(rsName.getString(3));
                }
                sqlN = "select name,phone,adress from ds_customer where cid = '"+order_bean.getCid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setCName(rsName.getString(1));
                    order_bean.setCPhone(rsName.getString(2));
                    order_bean.setCAdress(rsName.getString(3));
                }

                order_beans.add(order_bean);
            }
            stmt.close();
            conn.close();
            System.out.println("用户:"+sid+ "的订单信息");
            return  order_beans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }

        return order_beans;

    }

    //获取骑手订单信息
    public static ArrayList<Order_Bean> getRiderOrders(String rid){
        ArrayList<Order_Bean> order_beans = new ArrayList <>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            stmtName = conn.createStatement();
            String sql;
            sql = "select * from orders where rid = '"+rid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                Order_Bean order_bean = new Order_Bean();
                order_bean.setOid(rs.getString(1));
                order_bean.setSid(rs.getString(2));
                order_bean.setCid(rs.getString(3));
                order_bean.setRid(rs.getString(4));
                order_bean.setBillingTime(rs.getString(5));
                order_bean.setAcceptTime(rs.getString(6));
                order_bean.setFinishTime(rs.getString(7));
                order_bean.setSalary(rs.getString(8));
                order_bean.setTotal_Price(rs.getString(9));
                order_bean.setRTaken( Boolean.parseBoolean(rs.getString(10)));
                order_bean.setDelivery(Boolean.parseBoolean(rs.getString(11)));
                order_bean.setConfirm(Boolean.parseBoolean(rs.getString(12)));
                order_bean.setSTaken(Boolean.parseBoolean(rs.getString(13)));
                String sqlN = "select name,phone from ds_rider where rid = '"+order_bean.getRid()+"'";
                ResultSet rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setRName(rsName.getString(1));
                    order_bean.setRPhone(rsName.getString(2));
                }
                sqlN = "select name,phone,adress from ds_store where sid = '"+order_bean.getSid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setSName(rsName.getString(1));
                    order_bean.setSPhone(rsName.getString(2));
                    order_bean.setSAdress(rsName.getString(3));
                }
                sqlN = "select name,phone,adress from ds_customer where cid = '"+order_bean.getCid()+"'";
                rsName = stmtName.executeQuery(sqlN);
                if (rsName.next()) {
                    order_bean.setCName(rsName.getString(1));
                    order_bean.setCPhone(rsName.getString(2));
                    order_bean.setCAdress(rsName.getString(3));
                }

                order_beans.add(order_bean);
            }
            stmt.close();
            conn.close();
            System.out.println("用户:"+rid+ "的订单信息");
            return  order_beans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }

        return order_beans;

    }

    //查询订单的商品信息
    public static ArrayList<Good_Bean> getOrderGoods(String oid){
        ArrayList<Good_Bean> good_Beans = new ArrayList <>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            stmtName = conn.createStatement();
            String sql;
            sql = "select * from order_goods where oid = '"+oid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                  Good_Bean good_bean = new Good_Bean();
                  good_bean.setName(rs.getString(2));
                  good_bean.setPrice(rs.getString(3));
                  good_bean.setMany(rs.getString(4));
                  good_Beans.add(good_bean);
            }
            stmt.close();
            conn.close();
            System.out.println("订单:"+oid+ "的商品信息");
            return good_Beans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }

        return good_Beans;

    }

    //商家接单并下单
    public  static boolean storeTakeOrder(String oid){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update orders set " +
                    "isSTaken = 'true'"+
                    " where oid = '"+oid+"'";

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("订单:"+oid+"商家接单成功，等待骑手配送");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("订单:+"+oid+"接单失败");

        return  false;
    }

    //骑手接单
    public  static boolean riderTakeOrder(String oid,String rid){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update orders set " +
                    "isRTaken = 'true',"+
                    "rid = '"+rid+"',"+
                    "accepttime = '"+getNowDateStr()+"' "+
                    " where oid = '"+oid+"'";

            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("订单:"+oid+"骑手接单成功，正在配送");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("订单:+"+oid+"接单失败");

        return  false;
    }

    //刷新订单大厅
    public static ArrayList<Order_Bean> getAllOrders( ArrayList<Order_Bean> order_beans){
        ArrayList<Order_Bean> order_Beans = order_beans;
        Connection conn = null;
        Statement stmt = null;
        Statement stmtNameMore = null;
        Statement stmtNameLess = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            stmtNameMore = conn.createStatement();
            stmtNameLess = conn.createStatement();
            String sql;
            sql = "select * from orders ";
            ResultSet rs = stmt.executeQuery(sql);
            int num = 0;
//                // 展开结果集数据库
            while(rs.next()){
                if (order_Beans.size()>num) {
                    System.out.println(num);
                    order_Beans.get(num).setOid(rs.getString(1));
                    order_Beans.get(num).setSid(rs.getString(2));
                    order_Beans.get(num).setCid(rs.getString(3));
                    order_Beans.get(num).setRid(rs.getString(4));
                    order_Beans.get(num).setBillingTime(rs.getString(5));
                    order_Beans.get(num).setAcceptTime(rs.getString(6));
                    order_Beans.get(num).setFinishTime(rs.getString(7));
                    order_Beans.get(num).setSalary(rs.getString(8));
                    order_Beans.get(num).setTotal_Price(rs.getString(9));
                    order_Beans.get(num).setRTaken(Boolean.parseBoolean(rs.getString(10)));
                    order_Beans.get(num).setDelivery(Boolean.parseBoolean(rs.getString(11)));
                    order_Beans.get(num).setConfirm(Boolean.parseBoolean(rs.getString(12)));
                    order_Beans.get(num).setSTaken(Boolean.parseBoolean(rs.getString(13)));
                    String sqlN = "select name,phone from ds_rider where rid = '" + order_Beans.get(num).getRid() + "'";
                    ResultSet rsName = stmtNameMore.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_Beans.get(num).setRName(rsName.getString(1));
                        order_Beans.get(num).setRPhone(rsName.getString(2));
                    }
                    sqlN = "select name,phone,adress from ds_store where sid = '" + order_Beans.get(num).getSid() + "'";
                    rsName = stmtNameMore.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_Beans.get(num).setSName(rsName.getString(1));
                        order_Beans.get(num).setSPhone(rsName.getString(2));
                        order_Beans.get(num).setSAdress(rsName.getString(3));
                    }
                    sqlN = "select name,phone,adress from ds_customer where cid = '" + order_Beans.get(num).getCid() + "'";
                    rsName = stmtNameMore.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_Beans.get(num).setCName(rsName.getString(1));
                        order_Beans.get(num).setCPhone(rsName.getString(2));
                        order_Beans.get(num).setCAdress(rsName.getString(3));
                    }
                    num++;
                }
                else {
                    Order_Bean order_bean = new Order_Bean();
                    order_bean.setOid(rs.getString(1));
                    order_bean.setSid(rs.getString(2));
                    order_bean.setCid(rs.getString(3));
                    order_bean.setRid(rs.getString(4));
                    order_bean.setBillingTime(rs.getString(5));
                    order_bean.setAcceptTime(rs.getString(6));
                    order_bean.setFinishTime(rs.getString(7));
                    order_bean.setSalary(rs.getString(8));
                    order_bean.setTotal_Price(rs.getString(9));
                    order_bean.setRTaken( Boolean.parseBoolean(rs.getString(10)));
                    order_bean.setDelivery(Boolean.parseBoolean(rs.getString(11)));
                    order_bean.setConfirm(Boolean.parseBoolean(rs.getString(12)));
                    order_bean.setSTaken(Boolean.parseBoolean(rs.getString(13)));
                    String sqlN = "select name,phone from ds_rider where rid = '"+order_bean.getRid()+"'";
                    ResultSet rsName = stmtNameLess.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_bean.setRName(rsName.getString(1));
                        order_bean.setRPhone(rsName.getString(2));
                    }
                    sqlN = "select name,phone,adress from ds_store where sid = '"+order_bean.getSid()+"'";
                    rsName = stmtNameLess.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_bean.setSName(rsName.getString(1));
                        order_bean.setSPhone(rsName.getString(2));
                        order_bean.setSAdress(rsName.getString(3));
                    }
                    sqlN = "select name,phone,adress from ds_customer where cid = '"+order_bean.getCid()+"'";
                    rsName = stmtNameLess.executeQuery(sqlN);
                    if (rsName.next()) {
                        order_bean.setCName(rsName.getString(1));
                        order_bean.setCPhone(rsName.getString(2));
                        order_bean.setCAdress(rsName.getString(3));
                    }
                    num++;
                    order_Beans.add(order_bean);

                }

            }
            stmt.close();
            conn.close();
            System.out.println("所有的订单信息");
            return  order_Beans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }

        return order_Beans;

    }

    //骑手确认送达
    public static boolean riderDelivery(String oid){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update orders set " +
                    "isDelivery = 'true', "+
                    "finishTime = '"+getNowDateStr()+
                    "' where oid = '"+oid+"'";
            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("订单:"+oid+"骑手接单成功，正在配送");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("订单:+"+oid+"接单失败");


        return false;
    }

    //顾客确认收货
    public static boolean customerConfirm(String oid){
        Connection conn = null;
        Statement stmt = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update orders set " +
                    "isConfirm = 'true'"+
                    " where oid = '"+oid+"'";
            stmt.execute(sql);
            stmt.close();
            conn.close();
            System.out.println("订单:"+oid+"商家确认收货");
            return  true;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("订单:+"+oid+"接单失败");


        return false;
    }

    //获取商家评价
    public static ArrayList<Evaluation_Bean> getStoreEvaluationBeans(String sid)
    {
        ArrayList<Evaluation_Bean> evaluationBeans = new ArrayList <Evaluation_Bean>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_evaluation_store where sid = '"+sid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                Evaluation_Bean evaluation_bean = new Evaluation_Bean();
                evaluation_bean.setCname(rs.getString(2));
                evaluation_bean.setContent(rs.getString(3));
                evaluation_bean.setLevel(rs.getString(4));
                evaluation_bean.setTime(rs.getString(5));
                evaluation_bean.setReply(rs.getString(6));
                evaluation_bean.setCid(rs.getString(7));
                evaluationBeans.add(evaluation_bean);

            }
            stmt.close();
            conn.close();
            System.out.println("用户:"+sid+ "的订单信息");
            return  evaluationBeans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return evaluationBeans;
    }
    //获取骑手评价
    public static ArrayList<Evaluation_Bean> getRiderEvaluationBeans(String rid)
    {
        ArrayList<Evaluation_Bean> evaluationBeans = new ArrayList <Evaluation_Bean>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "select * from ds_evaluation_rider where rid = '"+rid+"'";
            ResultSet rs = stmt.executeQuery(sql);
//                // 展开结果集数据库
            while(rs.next()){
                Evaluation_Bean evaluation_bean = new Evaluation_Bean();
                evaluation_bean.setCname(rs.getString(2));
                evaluation_bean.setContent(rs.getString(3));
                evaluation_bean.setLevel(rs.getString(4));
                evaluation_bean.setTime(rs.getString(5));
                evaluationBeans.add(evaluation_bean);

            }
            stmt.close();
            conn.close();
            System.out.println("用户:"+rid+ "的订单信息");
            return  evaluationBeans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return evaluationBeans;
    }
    //回复评价
    public static ArrayList<Evaluation_Bean> replyStoreEvaluationBeans(String sid,String cid,String time,String reply)
    {
        ArrayList<Evaluation_Bean> evaluationBeans = new ArrayList <Evaluation_Bean>();
        Connection conn = null;
        Statement stmt = null;
        Statement stmtName = null;
        try{
            // 注册 JDBC 驱动
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 打开链接
            System.out.println("连接数据库...");
            conn = DriverManager.getConnection(Config.DB_URL, Config.USER, Config.PASS);
            System.out.println("获取数据库连接成功！");


            // 执行查询
            System.out.println(" 实例化Statement对象...");
            stmt = conn.createStatement();
            String sql;
            sql = "update  ds_evaluation_store set reply = '"+reply+"' where sid = '"+sid+"' and cid = '"+cid+"' and time = '"+time+"'";
            stmt.execute(sql);
//                // 展开结果集数据库
            stmt.close();
            conn.close();
            return  evaluationBeans;
//                // 展开结果集数据库

        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }finally{
            // 关闭资源
            try{
                if(stmt!=null) stmt.close();
            }catch(SQLException se2){
            }// 什么都不做
            try{
                if(conn!=null) conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
        return evaluationBeans;
    }

    public static void main(String[] args) {
        System.out.println(getDateStr());
        System.out.println(getNowDateStr());
        System.out.println(getOrderNum());
//        System.out.println("vip账号："+ register("hxw20","15665825636","123123","骑手")+"注冊成功");
//       addGood("s10000","田鸭","贼好吃","35");
//       evaluate("c10000","r10000","s10000","sxd","真棒呢，小老弟！","一般",getNowDateStr(),"老妹儿，给劲啊！","一般");
//        ArrayList<SingleGood_Panel> singleGood_panels = new ArrayList <SingleGood_Panel>();
//        SingleGood_Panel singleGood_panel = new SingleGood_Panel("田鸭","主要原料:鸭肉","35",0,null);
//        singleGood_panels.add(singleGood_panel);
//        buildOrder(getOrderNum(),
//                "s10000",
//                "c10000",
//                "",
//                getNowDateStr(),
//                "",
//                "",
//                "3.5",
//                "38.5",
//                false,
//                false,
//                false,
//                false,
//                singleGood_panels);
    }
}
