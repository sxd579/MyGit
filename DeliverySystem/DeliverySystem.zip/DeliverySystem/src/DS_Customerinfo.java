import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DS_Customerinfo {
    static String [] customerInfos = new String[3];
    public DS_Customerinfo(String id){
            customerInfos = Server_API.getCustomerInfo(id);
            if (customerInfos!=null) {
                customerinfo(id);
            }
    }
    static KeyListener listenerOnlyNum = new KeyListener() {

        @Override
        public void keyTyped(KeyEvent e) {
            int keyChar = e.getKeyChar();
            if (keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9) {

            } else {
                e.consume();//关键，屏蔽掉非法输入  
            }
        };

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    };
    public static void customerinfo(String id){
        JFrame frameRegister = new JFrame("个人信息");
        frameRegister.setBounds(600,200,700,600);

        frameRegister.setResizable(false);
        JPanel panelRegister = new JPanel();
        panelRegister.setBackground(new Color(252,230,201));
        panelRegister.setLayout(null);
        frameRegister.add(panelRegister);

        //标题
        JPanel panelTitle = new JPanel();
        JLabel labelTitle = new JLabel("个人信息");
        labelTitle.setFont(new Font("微软雅黑", Font.BOLD, 35));
        panelTitle.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelTitle.add(labelTitle);
        panelTitle.setOpaque(false);
        panelTitle.setBounds(40,50,280,100);

        //信息输入框
        JPanel panelInfo = new JPanel();
        panelInfo.setOpaque(false);
        panelInfo.setLayout(new GridLayout(5,1));
        panelInfo.setBounds(250,150,400,300);

        JPanel panelName = new JPanel();
        panelName.setOpaque(false);
        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelName = new JLabel("用户名：");
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldName =  new JTextField(10);
        textFieldName.setFont(new Font("微软雅黑", Font.BOLD, 20));


        JPanel panelCardNumber = new JPanel();
        panelCardNumber.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCardNumber.setOpaque(false);
        JLabel labelCardNumber = new JLabel("联系电话：");
        labelCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCardNumber =  new JTextField(10);
        textFieldCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCardNumber.addKeyListener(Server_API.listenerOnlyNum);

        JPanel panelAddress = new JPanel();
        panelAddress.setOpaque(false);
        panelAddress.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelAddress = new JLabel("收货地址：");
        labelAddress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldAdress =  new JTextField(10);
        textFieldAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));

        JPanel panelBt = new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonChange =new JButton("立即修改");
        buttonChange.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonChange.setBackground(Color.cyan);
        buttonChange.setOpaque(false);
        JButton buttonOK = new JButton("完成返回");
        buttonOK.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonOK.setBackground(Color.cyan);
        buttonOK.setOpaque(false);

        panelName.add(labelName);
        panelName.add(textFieldName);
        panelCardNumber.add(labelCardNumber);
        panelCardNumber.add(textFieldCardNumber);
        panelAddress.add(labelAddress);
        panelAddress.add(textFieldAdress);
        panelBt.add(buttonChange);
        panelBt.add(buttonOK);
        panelInfo.add(panelName);
        panelInfo.add(panelCardNumber);
        panelInfo.add(panelAddress);
        panelInfo.add(panelBt);

        panelRegister.add(panelTitle);
        panelRegister.add(panelInfo);

        frameRegister.setVisible(true);
        textFieldName.setText(customerInfos[0]);
        textFieldCardNumber.setText(customerInfos[1]);
        textFieldAdress.setText(customerInfos[2]);
        textFieldCardNumber.addKeyListener(listenerOnlyNum);
        textFieldCardNumber.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldCardNumber.getText().length()>19){
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        textFieldName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldName.getText().length()>11){
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        textFieldAdress.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldAdress.getText().length()>29){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        //修改
        buttonChange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customerInfos[0] = textFieldName.getText();
                customerInfos[1] = textFieldCardNumber.getText();
                customerInfos[2] = textFieldAdress.getText();
                if (!(textFieldName.getText().length()==0||textFieldCardNumber.getText().length()==0||textFieldAdress.getText().length()==0)) {
                    if (Server_API.changeCustomerInfo(id, customerInfos)) {
                        JOptionPane.showMessageDialog(null,
                                new JLabel("<html><h2><font color='red'><font size=\"25\">修改成功</font></h2></html>"),
                                "修改成功",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">信息有误或信息为空</font></h2></html>"),
                            "修改失败",
                            JOptionPane.ERROR_MESSAGE);
                }


            }
        });

        //返回
        buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameRegister.dispose();
            }
        });

    }

    public static void main(String[] args) {
        new DS_Customerinfo("c10000");
    }
}
