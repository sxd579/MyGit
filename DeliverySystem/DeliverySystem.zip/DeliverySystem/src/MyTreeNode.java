import javax.swing.tree.DefaultMutableTreeNode;
import java.util.ArrayList;

public class MyTreeNode extends DefaultMutableTreeNode {
    private int index=0;
    private String type;
    private String id;
    private ArrayList<String> goodname = new ArrayList <>();
    private ArrayList<String> unitCost= new ArrayList <>();
    private ArrayList<String> goodIntros= new ArrayList <>();
    private ArrayList<String> storeEvaluations = new ArrayList <>();
    private ArrayList<String> storeEvaluationsNames = new ArrayList <>();
    private ArrayList<String> storeEvaluationsLevel = new ArrayList <>();
    private ArrayList<String> storeEvaluationsTime = new ArrayList <>();
    private ArrayList<String> storeEvaluationsReply = new ArrayList <>();

    public void clearAll(){
        goodname.clear();
        unitCost.clear();
        goodIntros.clear();
        storeEvaluations.clear();
        storeEvaluationsNames.clear();
        storeEvaluationsLevel.clear();
        storeEvaluationsTime.clear();
        storeEvaluationsReply.clear();

    }
    public ArrayList <String> getStoreEvaluationsReply() {
        return storeEvaluationsReply;
    }

    public void setStoreEvaluationsReply(ArrayList <String> storeEvaluationsReply) {
        this.storeEvaluationsReply = storeEvaluationsReply;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    private String info;
    public MyTreeNode(String s, boolean b) {
        super(s,b);
        setInfo(s);
    }
    public ArrayList <String> getGoodname() {
        return goodname;
    }

    public void setGoodname(ArrayList <String> goodname) {
        this.goodname = goodname;
    }

    public ArrayList <String> getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(ArrayList <String> unitCost) {
        this.unitCost = unitCost;
    }

    public ArrayList <String> getGoodIntros() {
        return goodIntros;
    }

    public void setGoodIntros(ArrayList <String> goodIntros) {
        this.goodIntros = goodIntros;
    }

    public ArrayList <String> getStoreEvaluations() {
        return storeEvaluations;
    }

    public void setStoreEvaluations(ArrayList <String> storeEvaluations) {
        this.storeEvaluations = storeEvaluations;
    }

    public ArrayList <String> getStoreEvaluationsNames() {
        return storeEvaluationsNames;
    }

    public void setStoreEvaluationsNames(ArrayList <String> storeEvaluationsNames) {
        this.storeEvaluationsNames = storeEvaluationsNames;
    }

    public ArrayList <String> getStoreEvaluationsLevel() {
        return storeEvaluationsLevel;
    }

    public void setStoreEvaluationsLevel(ArrayList <String> storeEvaluationsLevel) {
        this.storeEvaluationsLevel = storeEvaluationsLevel;
    }

    public ArrayList <String> getStoreEvaluationsTime() {
        return storeEvaluationsTime;
    }

    public void setStoreEvaluationsTime(ArrayList <String> storeEvaluationsTime) {
        this.storeEvaluationsTime = storeEvaluationsTime;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
