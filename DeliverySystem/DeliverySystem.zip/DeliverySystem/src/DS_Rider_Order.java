import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DS_Rider_Order {
    ArrayList<Order_Bean> order_beans = new ArrayList <>();
    public DS_Rider_Order(String id){
        order_beans = Server_API.getRiderOrders(id);
        accepted_orderinfo(id);
    }
    public void  accepted_orderinfo(String id){
        JFrame frameOrders = new JFrame("订单信息");
        frameOrders.setBounds(600,200,510,650);
        JPanel panelOrders = new JPanel();
        panelOrders.setLayout(null);
        JLabel labelTitle = new JLabel("历史订单");
        labelTitle.setFont(new Font("微软雅黑", Font.BOLD, 25));
        labelTitle.setBounds(20,20,200,50);
        panelOrders.setBackground(new Color(176,224,230));

        //订单
        JPanel panelRecord = new JPanel();
        panelRecord.setBounds(0,60,500,520);
        panelRecord.setLayout(null);
        panelRecord.setBackground(new Color(176,224,230));
        JPanel panelRecords = new JPanel();
        panelRecords.setLayout(null);
        panelRecords.setBackground(new Color(176,224,230));
        JScrollPane scrollPaneRecords = new JScrollPane(panelRecords);
        scrollPaneRecords.setBounds(0,20,500,500);
        int height = 0;
        for (int i = 0;i<order_beans.size();i++){
            panelRecords.add(new SingleRiderOrder_Panel(
                    order_beans.get(order_beans.size()-1-i).getCName(),
                    order_beans.get(order_beans.size()-1-i).getBillingTime(),
                    order_beans.get(order_beans.size()-1-i).getTotal_Price(),
                    order_beans.get(order_beans.size()-1-i).getCAdress(),
                    order_beans.get(order_beans.size()-1-i).getSalary(),
                    order_beans.get(order_beans.size()-1-i).isSTaken(),
                    order_beans.get(order_beans.size()-1-i).isRTaken(),
                    order_beans.get(order_beans.size()-1-i).isDelivery(),
                    order_beans.get(order_beans.size()-1-i).isConfirm(),
                    i,
                    order_beans.get(order_beans.size()-1-i).getSid(),
                    order_beans.get(order_beans.size()-1-i).getRid(),
                    order_beans.get(order_beans.size()-1-i)));
            panelRecords.revalidate();
            height += 300;
        }
        panelRecords.setPreferredSize(new Dimension(scrollPaneRecords.getWidth(),height));



        panelRecord.add(scrollPaneRecords);
        panelOrders.add(labelTitle);
        panelOrders.add(panelRecord);
        frameOrders.add(panelOrders);
        frameOrders.setVisible(true);
        frameOrders.setResizable(false);
    }

    public static void main(String[] args) {
        new DS_Rider_Order("10000");
    }
}
