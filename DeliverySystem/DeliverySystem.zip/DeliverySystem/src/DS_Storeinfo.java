import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DS_Storeinfo {
    String [] storeInfos = new String[4];
    public DS_Storeinfo(String id){

       storeInfos = Server_API.getStoreInfo(id);
       if (storeInfos!=null){
           storeInfo(id);
       }

    }
    static KeyListener listenerOnlyNum = new KeyListener() {

        @Override
        public void keyTyped(KeyEvent e) {
            int keyChar = e.getKeyChar();
            if (keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9) {

            } else {
                e.consume();//关键，屏蔽掉非法输入  
            }
        };

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    };
    public void   storeInfo(String  id){  JFrame frameRegister = new JFrame("商家:"+id+"信息");
        frameRegister.setBounds(600, 200, 700, 450);

        frameRegister.setResizable(false);
        JPanel panelRegister = new JPanel();
        panelRegister.setBackground(new Color(252,230,201));
        panelRegister.setLayout(null);
        frameRegister.add(panelRegister);

        //标题
        JPanel panelTitle = new JPanel();
        JLabel labelTitle = new JLabel("商家信息");
        labelTitle.setFont(new Font("微软雅黑", Font.BOLD, 35));
        panelTitle.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelTitle.add(labelTitle);
        panelTitle.setOpaque(false);
        panelTitle.setBounds(40, 50, 280, 100);

        //信息输入框
        JPanel panelInfo = new JPanel();
        panelInfo.setOpaque(false);
        panelInfo.setLayout(new GridLayout(6, 1));
        panelInfo.setBounds(250, 150, 400, 300);

        JPanel panelName = new JPanel();
        panelName.setOpaque(false);
        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelName = new JLabel("店名：");
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldName = new JTextField(10);
        textFieldName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldName.setText(storeInfos[0]);


        JPanel panelCardNumber = new JPanel();
        panelCardNumber.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCardNumber.setOpaque(false);
        JLabel labelCardNumber = new JLabel("联系电话：");
        labelCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCardNumber = new JTextField(10);
        textFieldCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCardNumber.setText(storeInfos[1]);

        JPanel panelAddress = new JPanel();
        panelAddress.setOpaque(false);
        panelAddress.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelAddress = new JLabel("商家地址：");
        labelAddress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldAdress = new JTextField(10);
        textFieldAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldAdress.setText(storeInfos[2]);

        JPanel panelType = new JPanel();
        panelType.setOpaque(false);
        panelType.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelType = new JLabel("类型: ");
        labelType.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JComboBox<String> comboBoxType = new JComboBox <String>();
        comboBoxType.setFont(new Font("微软雅黑", Font.BOLD, 20));
        comboBoxType.setBackground(Color.white);
        comboBoxType.addItem("尚未填写");
        comboBoxType.addItem("速食简餐");
        comboBoxType.addItem("米粉面馆");
        comboBoxType.addItem("水果生鲜");
        comboBoxType.addItem("甜品饮品");
        comboBoxType.addItem("炸鸡汉堡");
        comboBoxType.addItem("包子粥店");
        comboBoxType.addItem("超市便利");
        if (storeInfos[3].equals("尚未填写")){
            comboBoxType.setSelectedIndex(0);
        }
        if (storeInfos[3].equals("速食简餐")){
            comboBoxType.setSelectedIndex(1);
        }
        if (storeInfos[3].equals("米粉面馆")){
            comboBoxType.setSelectedIndex(2);
        }
        if (storeInfos[3].equals("水果生鲜")){
            comboBoxType.setSelectedIndex(3);
        }
        if (storeInfos[3].equals("甜品饮品")){
            comboBoxType.setSelectedIndex(4);
        }
        if (storeInfos[3].equals("炸鸡汉堡")){
            comboBoxType.setSelectedIndex(5);
        }
        if (storeInfos[3].equals("包子粥店")){
            comboBoxType.setSelectedIndex(6);
        }
        if (storeInfos[3].equals("超市便利")){
            comboBoxType.setSelectedIndex(7);
        }

        JPanel panelBt = new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonChange = new JButton("立即修改");
        buttonChange.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonChange.setBackground(Color.cyan);
        buttonChange.setOpaque(false);
        JButton buttonOK = new JButton("完成返回");
        buttonOK.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonOK.setBackground(Color.cyan);
        buttonOK.setOpaque(false);

        panelName.add(labelName);
        panelName.add(textFieldName);
        panelCardNumber.add(labelCardNumber);
        panelCardNumber.add(textFieldCardNumber);
        panelAddress.add(labelAddress);
        panelAddress.add(textFieldAdress);
        panelType.add(labelType);
        panelType.add(comboBoxType);
        panelBt.add(buttonChange);
        panelBt.add(buttonOK);
        panelInfo.add(panelName);
        panelInfo.add(panelCardNumber);
        panelInfo.add(panelAddress);
        panelInfo.add(panelType);
        panelInfo.add(panelBt);

        panelRegister.add(panelTitle);
        panelRegister.add(panelInfo);

        frameRegister.setVisible(true);
        textFieldCardNumber.addKeyListener(listenerOnlyNum);
        textFieldCardNumber.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldCardNumber.getText().length() > 11) {
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        textFieldName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldName.getText().length() > 8) {
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        //修改
        buttonChange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                storeInfos[0] = textFieldName.getText();
                storeInfos[1] = textFieldCardNumber.getText();
                storeInfos[2] = textFieldAdress.getText();
                storeInfos[3] = comboBoxType.getSelectedItem().toString();
                if (!(textFieldName.getText().length()==0||textFieldCardNumber.getText().length()==0||textFieldAdress.getText().length()==0)) {
                    if (Server_API.changeStoreInfo(id, storeInfos)) {
                        JOptionPane.showMessageDialog(null,
                                new JLabel("<html><h2><font color='red'><font size=\"25\">修改成功</font></h2></html>"),
                                "修改成功",
                                JOptionPane.INFORMATION_MESSAGE);
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\">信息有误或信息为空</font></h2></html>"),
                            "修改失败",
                            JOptionPane.ERROR_MESSAGE);
                }

            }
        });

        //返回
        buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameRegister.dispose();
            }
        });
    }

    public static void main(String[] args) {
        new DS_Storeinfo("s10001");
    }
}

