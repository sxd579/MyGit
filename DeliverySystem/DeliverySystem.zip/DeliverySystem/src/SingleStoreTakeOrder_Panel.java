import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleStoreTakeOrder_Panel extends  JPanel{
    public SingleStoreTakeOrder_Panel(String cName ,
                                     String time,
                                     String total_Price,
                                     String adress,
                                     String salary,
                                     boolean isSTaken,
                                     boolean isRTaken,
                                     boolean isDelivery,
                                     boolean isConfirm,
                                     int num,
                                     String storeId,
                                     String riderId,
                                     Order_Bean order_bean)
    {
        this.setBackground(Color.white);
        this.setBounds(20,20+300*num,500,280);
        JLabel labelName = new JLabel("客户:"+cName);
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelTime = new JLabel("需送达时间:"+time);
        labelTime.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldAdress = new JTextField(10);
        textFieldAdress.setEditable(false);
        textFieldAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldAdress.setText("需送达地点:"+adress);
        JLabel labelSalary =new JLabel("配送费:￥"+salary);
        labelSalary.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelStatus = new JLabel("");
        labelStatus.setFont(new Font("微软雅黑", Font.BOLD, 20));
        if (!isSTaken){
            labelStatus.setText("订单状态:等待商家接单……");
        }
        if (isSTaken&&!isRTaken){
            labelStatus.setText("订单状态:正在寻找骑手ing……");
        }
        if (isSTaken&&isRTaken&&!isDelivery){
            labelStatus.setText("订单状态:骑手正在配送ing……");
        }
        if (isSTaken&&isRTaken&&isDelivery){
            labelStatus.setText("订单状态:骑手已送达，等待客户确认送达……");
        }
        if (isSTaken&&isRTaken&&isDelivery&&isConfirm){
            labelStatus.setText("订单状态:已送达");
        }

        JPanel panelBt =new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonTakeOrder = new JButton("接单/发单");
        buttonTakeOrder.setBackground(Color.cyan);
        buttonTakeOrder.setOpaque(false);
        buttonTakeOrder.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JButton buttonOrderInfo = new JButton("订单详情");
        buttonOrderInfo.setBackground(Color.cyan);
        buttonOrderInfo.setOpaque(false);
        buttonOrderInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JButton buttonContact = new JButton("联系顾客/骑手");
        buttonContact.setBackground(Color.cyan);
        buttonContact.setOpaque(false);
        buttonContact.setFont(new Font("微软雅黑", Font.BOLD, 20));

        //联系客户,骑手
        buttonContact.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 骑手电话:  "+order_bean.getRPhone()+"<br>" +
                                "顾客电话:  "+order_bean.getCPhone()+"<br></font></h2></html>"),
                        "确认送达",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //接单发单
        buttonTakeOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 Server_API.storeTakeOrder(order_bean.getOid());
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 接单成功，正在寻找骑手</font></h2></html>"),
                        "接单成功",
                        JOptionPane.INFORMATION_MESSAGE);

                buttonTakeOrder.setEnabled(false);
            }
        });

        buttonOrderInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Order(
                        order_bean.getOid(),
                        order_bean.getSid(),
                        order_bean.getSName(),
                        order_bean.getSAdress(),
                        order_bean.getSPhone(),
                        order_bean.getCid(),
                        order_bean.getCAdress(),
                        order_bean.getCPhone(),
                        order_bean.getCName(),
                        order_bean.getRid(),
                        order_bean.getRName(),
                        order_bean.getRPhone(),
                        order_bean.getBillingTime(),
                        order_bean.getAcceptTime(),
                        order_bean.getFinishTime(),
                        order_bean.getSalary(),
                        order_bean.getTotal_Price(),
                        order_bean.isSTaken(),
                        order_bean.isRTaken(),
                        order_bean.isDelivery(),
                        order_bean.isConfirm()
                );

            }
        });

       if (!isSTaken){panelBt.add(buttonTakeOrder);}
        panelBt.add(buttonOrderInfo);
        panelBt.add(buttonContact);
        this.setLayout(new GridLayout(6,1));
        this.add(labelName);
        this.add(labelTime);
        this.add(textFieldAdress);
        this.add(labelSalary);
        this.add(labelStatus);
        this.add(panelBt);

    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,280);
//        frameTest.add(new SingleStoreTakeOrder_Panel("店家1","2019年8月24日09:38:09","xxxxxxxxx111111111111","3.5",false,false,false,false,0));
        frameTest.setVisible(true);
    }
}
