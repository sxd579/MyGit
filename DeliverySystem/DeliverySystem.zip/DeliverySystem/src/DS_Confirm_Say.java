import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DS_Confirm_Say {
    public DS_Confirm_Say(String cid,String sid,String rid,String cname){
        confirmsay(cid,sid,rid,cname);
    }
    public void confirmsay(String cid,String sid,String rid,String cname){
        JFrame frameConfirm_Say = new JFrame("评价:");
        frameConfirm_Say.setBounds(600,200,800,550);
        JPanel panelConfirm_Say = new JPanel();
        panelConfirm_Say.setLayout(null);
        panelConfirm_Say.setBackground(new Color(252,230,201));


        JLabel labelRider = new JLabel("请对骑手进行评价");
        labelRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        labelRider.setBounds(30,30,300,50);

        JPanel panelRider = new JPanel();
        panelRider.setBackground(new Color(252,230,201));
        panelRider.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelRider.setBounds(330,30,400,50);
        JCheckBox buttonGoodRider = new JCheckBox("好",true);
        buttonGoodRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonGoodRider.setBackground(Color.cyan);
        buttonGoodRider.setOpaque(false);
        JCheckBox buttonLittleRider = new JCheckBox("一般");
        buttonLittleRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonLittleRider.setBackground(Color.cyan);
        buttonLittleRider.setOpaque(false);
        JCheckBox buttonBadRider = new JCheckBox("差");
        buttonBadRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonBadRider.setBackground(Color.cyan);
        buttonBadRider.setOpaque(false);
        ButtonGroup gRider = new ButtonGroup();
        gRider.add(buttonGoodRider);
        gRider.add(buttonLittleRider);
        gRider.add(buttonBadRider);
        panelRider.add(buttonGoodRider);
        panelRider.add(buttonLittleRider);
        panelRider.add(buttonBadRider);

        JLabel labelStroe = new JLabel("请对商家进行评价");
        labelStroe.setBounds(30,230,300,50);
        labelStroe.setFont(new Font("微软雅黑", Font.BOLD, 20));

        JPanel panelStore = new JPanel();
        panelStore.setBackground(new Color(252,230,201));
        panelStore.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelStore.setBounds(330,230,400,50);
        JCheckBox buttonGoodStore = new JCheckBox("好",true);
        buttonGoodStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonGoodStore.setBackground(Color.cyan);
        buttonGoodStore.setOpaque(false);
        JCheckBox buttonLittleStore = new JCheckBox("一般");
        buttonLittleStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonLittleStore.setBackground(Color.cyan);
        buttonLittleStore.setOpaque(false);
        JCheckBox buttonBadStore = new JCheckBox("差");
        buttonBadStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonBadStore.setBackground(Color.cyan);
        buttonBadStore.setOpaque(false);
        ButtonGroup gStore = new ButtonGroup();
        gStore.add(buttonGoodStore);
        gStore.add(buttonLittleStore);
        gStore.add(buttonBadStore);
        panelStore.add(buttonGoodStore);
        panelStore.add(buttonLittleStore);
        panelStore.add(buttonBadStore);

        JTextArea textAreaRider = new JTextArea(4,50);
        textAreaRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textAreaRider.setBounds(30,80,700,150);
        textAreaRider.setBackground(Color.cyan);
        JTextArea textAreaStore = new JTextArea(4,50);
        textAreaStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textAreaStore.setBounds(30,280,700,150);
        textAreaStore.setBackground(Color.cyan);
        textAreaRider.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textAreaRider.getText().length()>29){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });
        textAreaStore.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textAreaStore.getText().length()>29){
                    e.consume();
                }

            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        JButton buttonSay = new JButton("评价");
        buttonSay.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonSay.setBounds(300,450,200,50);
        buttonSay.setBackground(Color.cyan);
        buttonSay.setOpaque(false);

        panelConfirm_Say.add(buttonSay);
        panelConfirm_Say.add(labelRider);
        panelConfirm_Say.add(labelStroe);
        panelConfirm_Say.add(textAreaRider);
        panelConfirm_Say.add(textAreaStore);
        panelConfirm_Say.add(panelRider);
        panelConfirm_Say.add(panelStore);
        frameConfirm_Say.add(panelConfirm_Say);
        frameConfirm_Say.setVisible(true);
        frameConfirm_Say.setResizable(false);

        buttonSay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //评价
                String levelRider = "";
                String levelStroe = "";
                if (buttonBadStore.isSelected()){levelStroe = "差";}
                if (buttonBadRider.isSelected()){levelRider = "差";}
                if (buttonLittleStore.isSelected()){levelStroe = "一般";}
                if (buttonLittleRider.isSelected()){levelRider = "一般";}
                if (buttonGoodStore.isSelected()){levelStroe = "好";}
                if (buttonGoodRider.isSelected()){levelRider = "好";}
               if (Server_API.evaluate(cid,rid,sid,cname,textAreaRider.getText(),levelRider,Server_API.getNowDateStr(),textAreaStore.getText(),levelStroe)){
                   JOptionPane.showMessageDialog(null,
                           new JLabel("<html><h2><font color='red'><font size=\"25\">评价成功</font></h2></html>"),
                           "评价成功",
                           JOptionPane.INFORMATION_MESSAGE);
               }
               else {
                   JOptionPane.showMessageDialog(null,
                           new JLabel("<html><h2><font color='red'><font size=\"25\">评价失败</font></h2></html>"),
                           "评价失败",
                           JOptionPane.ERROR_MESSAGE);
               }
                buttonSay.setEnabled(false);
                frameConfirm_Say.dispose();
            }
        });
    }

    public static void main(String[] args) {
//      new DS_Confirm_Say("");
    }
}
