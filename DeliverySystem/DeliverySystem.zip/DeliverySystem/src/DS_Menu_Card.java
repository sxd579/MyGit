import oracle.jrockit.jfr.JFR;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class DS_Menu_Card extends JPanel {
    float total_Price  = (float) 3.5;
    JLabel label_total_Price;
    ArrayList<SingleGood_Panel> singleGood_panels = new ArrayList <SingleGood_Panel>();
    public DS_Menu_Card(String name,
                        ArrayList<String> goodname,
                        ArrayList<String> unitCost,
                        ArrayList<String> goodIntros,
                        ArrayList<String> storeEvaluations,
                        ArrayList<String> storeEvaluationsNames,
                        ArrayList<String> storeEvaluationsLevel,
                        ArrayList<String> storeEvaluationsTime,
                        ArrayList<String> storeEvaluationsReply,
                        String sid,
                        String cid
    ){
        singleGood_panels.clear();
        this.setLayout(null);
        this.setBackground(new Color(176,224,230));
        JPanel panelName = new JPanel(){
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawLine(0, 58, 510, 58);
            }
        };
        //店名
        panelName.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelName.setBackground(new Color(176,224,230));
        JLabel labelName = new JLabel(name);
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 25));
        panelName.add(labelName);
        ///距离和配送时间
        JLabel labelInfo = new JLabel("（配送费:￥3.5）");
        labelInfo.setFont(new Font("微软雅黑", Font.BOLD, 15));
        panelName.add(labelInfo);
        panelName.setBounds(0,0,510,60);


        //选项卡
        JTabbedPane jp = new JTabbedPane(JTabbedPane.TOP);
        jp.setFont(new Font("微软雅黑", Font.BOLD, 15));
        jp.setBounds(0,60,510,500);




        ///点餐
        JPanel panelOrder = new JPanel();
        panelOrder.setLayout(null);
        panelOrder.setBounds(0,0,500,600);
        panelOrder.setBackground(new Color(176,224,230));
        JPanel panelGood  = new JPanel();
        panelGood.setBackground(new Color(176,224,230));
        panelGood.setLayout(null);
//        panelGood.setBounds(0,60,500,540);
       JScrollPane scrollPaneGood = new JScrollPane(panelGood);
       scrollPaneGood.setBounds(0,0,500,400);
       int height = 0;
        for (int i = 0;i<goodname.size();i++){
            SingleGood_Panel singleGood_panel =new SingleGood_Panel(goodname.get(i),goodIntros.get(i),unitCost.get(i),i,this);
            singleGood_panels.add(singleGood_panel);
            panelGood.add(singleGood_panel);
            panelGood.revalidate();
            height+=200;
        }
        panelGood.setPreferredSize(new Dimension(scrollPaneGood.getWidth(),height));
        ///确认下单 总价格
        label_total_Price = new JLabel("总价格：￥"+total_Price);
        label_total_Price.setFont(new Font("微软雅黑", Font.BOLD, 20));
        label_total_Price.setBounds(100,420,200,50);
        JButton buttonConfirm = new JButton("确认下单");
        buttonConfirm.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonConfirm.setBounds(300,410,200,50);
        buttonConfirm.setBackground(Color.cyan);
        buttonConfirm.setOpaque(false);

        panelOrder.add(scrollPaneGood);
        panelOrder.add(buttonConfirm);
        panelOrder.add(label_total_Price);

        //评价
        JPanel panelEvaluation = new JPanel();
        panelEvaluation.setLayout(null);
        panelEvaluation.setBounds(0,0,500,620);
        panelEvaluation.setBackground(new Color(176,224,230));

        JPanel panelEvaluate = new JPanel();
        panelEvaluate.setLayout(null);
        panelEvaluate.setBackground(new Color(176,224,230));
        JScrollPane scrollPaneEvaluation = new JScrollPane(panelEvaluate);
        scrollPaneEvaluation.setBounds(0,0,500,450);
        int height1 = 0;
//        for (int i = 0;i<10;i++){
//            panelEvaluate.add(new SingleClientSay_Panel("sxd","味道还是一如既往的好，价格实惠","*****","2019年8月22日15:15:08","",i));
//            panelEvaluate.revalidate();
//            height1 +=220;
//        }
        for (int i = 0;i<storeEvaluations.size();i++){
            panelEvaluate.add(new SingleClientSay_Panel(storeEvaluationsNames.get(i),storeEvaluations.get(i),storeEvaluationsLevel.get(i),storeEvaluationsTime.get(i),storeEvaluationsReply.get(i),i));
            panelEvaluate.revalidate();
            height1 +=270;
        }
        panelEvaluate.setPreferredSize(new Dimension(scrollPaneEvaluation.getWidth(),height1));
        panelEvaluation.add(scrollPaneEvaluation);






        jp.addTab("点餐",panelOrder);
        jp.addTab("评价",panelEvaluation);



        buttonConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (singleGood_panels!=null){
                    Server_API.buildOrder(Server_API.getOrderNum(),
                            sid,
                            cid,
                            "",
                            Server_API.getNowDateStr(),
                            "",
                            "",
                            "3.5",
                            String.valueOf(total_Price),
                            false,
                            false,
                            false,
                            false,
                            singleGood_panels);

                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 下单成功，等待商家接单……</font></h2></html>"),
                            "下单成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 下单失败,并无商品</font></h2></html>"),
                            "逗我玩？",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        this.add(jp);
        this.add(panelName);

    }



    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,510,600);
        frameTest.add(new DS_Menu_Card("店家1",null,null,null,null,null,null,null,null,null,null));
        frameTest.setVisible(true);
        frameTest.setResizable(false);

    }
}
