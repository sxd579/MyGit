import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleGood_Panel extends JPanel{
    int odNums = 0;
    JLabel labelOdNums;
    String name;
    String price;
    public SingleGood_Panel(String name,String intro,String price,int num,DS_Menu_Card ds_menu_card){
        this.name  = name;
        this.price = price;
        this.setBackground(Color.white);
        this.setLayout(new GridLayout(4,1));
        this.setBounds(20,20+200*num,400,180);
       JLabel labelName = new JLabel(name);
       labelName.setFont(new Font("微软雅黑", Font.BOLD, 25));
       JLabel labelIntro = new JLabel(intro);
       labelIntro.setFont(new Font("微软雅黑", Font.BOLD, 15));
       JLabel labelCost = new JLabel("￥"+price);
       labelCost.setFont(new Font("微软雅黑", Font.BOLD, 20));

       //点餐
       JPanel panelOd = new JPanel();
       panelOd.setLayout(new FlowLayout(FlowLayout.LEFT));
       labelOdNums = new JLabel(""+odNums);
       labelOdNums.setFont(new Font("微软雅黑", Font.BOLD, 20));
       JButton buttonAdd = new JButton("+");
       buttonAdd.setBackground(Color.cyan);
       buttonAdd.setOpaque(false);
       buttonAdd.setFont(new Font("微软雅黑", Font.BOLD, 20));
       JButton buttonCut = new JButton("-");
       buttonCut.setFont(new Font("微软雅黑", Font.BOLD, 20));
       buttonCut.setBackground(Color.cyan);
       buttonCut.setOpaque(false);
       panelOd.add(buttonCut);
       panelOd.add(labelOdNums);
       panelOd.add(buttonAdd);
       panelOd.setOpaque(false);
       buttonAdd.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               odNums++;
               labelOdNums.setText(""+odNums);
               ds_menu_card.total_Price += Float.valueOf(price);
               ds_menu_card.label_total_Price.setText("总价格：￥"+ds_menu_card.total_Price);
           }
       });
       buttonCut.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent e) {
               if (odNums>0) {
                   odNums--;
                   labelOdNums.setText("" + odNums);
                   ds_menu_card.total_Price -= Float.valueOf(price);
                   ds_menu_card.label_total_Price.setText("总价格：￥"+ds_menu_card.total_Price);
                   ;
               }
           }
       });

       this.add(labelName);
       this.add(labelIntro);
       this.add(labelCost);
       this.add(panelOd);
    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,150);
        frameTest.add(new SingleGood_Panel("田鸭","主要原料:鸭肉","35",1,null));
        frameTest.setVisible(true);
    }
}

