import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class DS_Register {
    public DS_Register(){
          register();

    }
    static KeyListener listenerOnlyNum = new KeyListener() {

        @Override
        public void keyTyped(KeyEvent e) {
            int keyChar = e.getKeyChar();
            if (keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9) {

            } else {
                e.consume();//关键，屏蔽掉非法输入  
            }
        };

        @Override
        public void keyPressed(KeyEvent e) {

        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    };
    public  static void  register(){
        JFrame frameRegister = new JFrame("注册");
        frameRegister.setBounds(600,200,700,600);

        frameRegister.setResizable(false);
        JPanel panelRegister = new JPanel();
        panelRegister.setBackground(new Color(252,230,201));
        panelRegister.setLayout(null);
        frameRegister.add(panelRegister);

        //标题
        JPanel panelTitle = new JPanel();
        JLabel labelTitle = new JLabel("欢迎注册,朋友！");
        labelTitle.setFont(new Font("微软雅黑", Font.BOLD, 35));
        panelTitle.setLayout(new FlowLayout(FlowLayout.CENTER));
        panelTitle.add(labelTitle);
        panelTitle.setOpaque(false);
        panelTitle.setBounds(100,50,300,100);

        //信息输入框
        JPanel panelInfo = new JPanel();
        panelInfo.setOpaque(false);
        panelInfo.setLayout(new GridLayout(5,1));
        panelInfo.setBounds(250,150,400,300);

        JPanel panelName = new JPanel();
        panelName.setOpaque(false);
        panelName.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelName = new JLabel("用户名：");
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldName =  new JTextField(10);
        textFieldName.setFont(new Font("微软雅黑", Font.BOLD, 20));


        JPanel panelCardNumber = new JPanel();
        panelCardNumber.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCardNumber.setOpaque(false);
        JLabel labelCardNumber = new JLabel("联系电话：");
        labelCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCardNumber =  new JTextField(10);
        textFieldCardNumber.setFont(new Font("微软雅黑", Font.BOLD, 20));

        JPanel panelPsw = new JPanel();
        panelPsw.setOpaque(false);
        panelPsw.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelPsw = new JLabel("密码：");
        labelPsw.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JPasswordField textFieldPsw =  new JPasswordField(10);
        textFieldPsw.setEchoChar('*');
        textFieldPsw.setFont(new Font("微软雅黑", Font.BOLD, 20));


        JPanel panelType = new JPanel();
        panelType.setOpaque(false);
        panelType.setLayout(new FlowLayout(FlowLayout.LEFT));
        JCheckBox buttonCustomer = new JCheckBox("顾客",true);
        buttonCustomer.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonCustomer.setBackground(new Color(0,0,0));
        buttonCustomer.setOpaque(false);
        JCheckBox buttonRider = new JCheckBox("骑手");
        buttonRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRider.setBackground(new Color(0,0,0));
        buttonRider.setOpaque(false);
        JCheckBox buttonStore = new JCheckBox("加盟商家");
        buttonStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonStore.setBackground(new Color(0,0,0));
        buttonStore.setOpaque(false);
        ButtonGroup g = new ButtonGroup();
        g.add(buttonCustomer);
        g.add(buttonRider);
        g.add(buttonStore);
        JLabel labelType = new JLabel("您是：");
        labelType.setFont(new Font("微软雅黑", Font.BOLD, 20));


        JPanel panelBt = new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonRegister =new JButton("立即注册");
        buttonRegister.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonRegister.setBackground(Color.cyan);
        buttonRegister.setOpaque(false);
        JButton buttonOK = new JButton("完成返回");
        buttonOK.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonOK.setBackground(Color.cyan);
        buttonOK.setOpaque(false);

        panelName.add(labelName);
        panelName.add(textFieldName);
        panelCardNumber.add(labelCardNumber);
        panelCardNumber.add(textFieldCardNumber);
        panelPsw.add(labelPsw);
        panelPsw.add(textFieldPsw);
        panelType.add(labelType);
        panelType.add(buttonCustomer);
        panelType.add(buttonRider);
        panelType.add(buttonStore);
        panelBt.add(buttonRegister);
        panelBt.add(buttonOK);
        panelInfo.add(panelName);
        panelInfo.add(panelCardNumber);
        panelInfo.add(panelPsw);
        panelInfo.add(panelType);
        panelInfo.add(panelBt);

        panelRegister.add(panelTitle);
        panelRegister.add(panelInfo);

        frameRegister.setVisible(true);
        textFieldName.setText("");
        textFieldCardNumber.setText("");
        textFieldPsw.setText("");
        textFieldCardNumber.addKeyListener(listenerOnlyNum);
        textFieldCardNumber.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldCardNumber.getText().length()>19){
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        textFieldName.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (textFieldName.getText().length()>11){
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        textFieldPsw.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                if (String.valueOf(textFieldPsw.getPassword()).length()>11){
                    e.consume();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {

            }

            @Override
            public void keyReleased(KeyEvent e) {

            }
        });

        //注册
        buttonRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = "";
                if (buttonRider.isSelected()) {
                    id = Server_API.register(textFieldName.getText(), textFieldCardNumber.getText(), String.valueOf(textFieldPsw.getPassword()),"骑手");
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 注册成功,您的账号为:"+id+"</font></h2></html>"),
                            "注册成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else if (buttonCustomer.isSelected()) {
                    id =Server_API.register(textFieldName.getText(), textFieldCardNumber.getText(), String.valueOf(textFieldPsw.getPassword()),"顾客");
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 注册成功,您的账号为:"+id+"</font></h2></html>"),
                            "注册成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else if (buttonStore.isSelected()) {
                    id =Server_API.register(textFieldName.getText(), textFieldCardNumber.getText(), String.valueOf(textFieldPsw.getPassword()),"商家");
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 注册成功,您的账号为:"+id+"</font></h2></html>"),
                            "注册成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        //返回
        buttonOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameRegister.dispose();
            }
        });

    }
}
