import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleRiderTakeOrder_Panel extends JPanel{
        public SingleRiderTakeOrder_Panel( String oid ,
                                            String name,
                                            String total_Price,
                                            String adress,
                                            String salary,
                                            boolean isSTaken,
                                            boolean isRTaken,
                                            boolean isDelivery,
                                            boolean isConfirm,
                                            int num,
                                            String storeId,
                                            String riderId,
                                            Order_Bean order_bean,
                                            String rid
                                            )
    {
        this.setBackground(Color.white);
        this.setBounds(20,20+270*num,530,250);
        JLabel labelStoreName = new JLabel(name+" ("+adress+")");
        labelStoreName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelOid = new JLabel("订单号:"+oid);
        labelOid.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldAdress = new JTextField(10);
        textFieldAdress.setEditable(false);
        textFieldAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldAdress.setText("需送达地点:"+adress);
        JLabel labelSalary =new JLabel("配送费:￥"+salary);
        labelSalary.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JPanel panelBt = new JPanel();
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelBt.setBackground(Color.white);
        JButton buttonTakeOrder = new JButton("立即接单");
        buttonTakeOrder.setBackground(Color.cyan);
        buttonTakeOrder.setOpaque(false);
        buttonTakeOrder.setFont(new Font("微软雅黑", Font.BOLD, 20));
        panelBt.add(buttonTakeOrder);
        buttonTakeOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Server_API.riderTakeOrder(order_bean.getOid(),rid);
                buttonTakeOrder.setEnabled(false);
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 接单成功，骑手开始配送……</font></h2></html>"),
                        "接单成功",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        this.setLayout(new GridLayout(5,1));
        this.add(labelOid);
        this.add(labelStoreName);
        this.add(textFieldAdress);
        this.add(labelSalary);
        this.add(panelBt);

    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,600,250);
//        frameTest.add(new SingleRiderTakeOrder_Panel("店家1","2019年8月24日09:38:09","xxxxxxxxxxxsadasasxx","xxxxxxxxx111111111111","3.5",0));
        frameTest.setVisible(true);
    }
}
