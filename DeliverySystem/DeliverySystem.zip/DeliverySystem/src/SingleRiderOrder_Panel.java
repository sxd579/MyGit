import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleRiderOrder_Panel extends  JPanel{
    public SingleRiderOrder_Panel(String name ,
                                  String time,
                                  String total_Price,
                                  String adress,
                                  String salary,
                                  boolean isSTaken,
                                  boolean isRTaken,
                                  boolean isDelivery,
                                  boolean isConfirm,
                                  int num,
                                  String storeId,
                                  String riderId,
                                  Order_Bean order_bean
    ){
        this.setBackground(Color.white);
        this.setBounds(20,20+300*num,1000,280);
        JLabel labelStoreName = new JLabel(name+" ("+adress+")");
        labelStoreName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelTime = new JLabel("需送达时间:"+time);
        labelTime.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldAdress = new JTextField(10);
        textFieldAdress.setEditable(false);
        textFieldAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldAdress.setText("需送达地点:"+adress);
        JLabel labelSalary =new JLabel("配送费:￥"+salary);
        labelSalary.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JPanel panelBt = new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonTakeOrder = new JButton("确认送达");
        buttonTakeOrder.setBackground(Color.cyan);
        buttonTakeOrder.setOpaque(false);
        buttonTakeOrder.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JButton buttonContact = new JButton("联系商家/客户");
        buttonContact.setBackground(Color.cyan);
        buttonContact.setOpaque(false);
        buttonContact.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelStatus = new JLabel("");
        labelStatus.setFont(new Font("微软雅黑", Font.BOLD, 20));
        if (!isSTaken){
            labelStatus.setText("订单状态:等待商家接单……");
        }
        if (isSTaken&&!isRTaken){
            labelStatus.setText("订单状态:正在寻找骑手ing……");
        }
        if (isSTaken&&isRTaken&&!isDelivery){
            labelStatus.setText("订单状态:骑手正在配送ing……");
        }
        if (isSTaken&&isRTaken&&isDelivery){
            labelStatus.setText("订单状态:骑手已送达，等待客户确认送达……");
        }
        if (isSTaken&&isRTaken&&isDelivery&&isConfirm){
            labelStatus.setText("订单状态:已送达");
        }



        JButton buttonOrderInfo = new JButton("订单详情");
        buttonOrderInfo.setBackground(Color.cyan);
        buttonOrderInfo.setOpaque(false);
        buttonOrderInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));
        this.setLayout(new GridLayout(6,1));
        this.add(labelStoreName);
        this.add(labelTime);
        this.add(textFieldAdress);
        this.add(labelSalary);
        this.add(labelStatus);
        if (isConfirm){
            panelBt.add(buttonOrderInfo);
        }
        else if (isDelivery){
            panelBt.add(buttonContact);
            panelBt.add(buttonOrderInfo);
        }
        else {
            panelBt.add(buttonContact);
            panelBt.add(buttonTakeOrder);
            panelBt.add(buttonOrderInfo);

        }
        this.add(panelBt);

        //联系商家客户
        buttonContact.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 商家电话:  "+order_bean.getSPhone()+"<br>" +
                                "顾客电话:  "+order_bean.getCPhone()+"<br></font></h2></html>"),
                        "确认送达",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        //确认送达
        buttonTakeOrder.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Server_API.riderDelivery(order_bean.getOid());
                buttonTakeOrder.setEnabled(false);
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 骑手确认送达,等待客户确认收货……</font></h2></html>"),
                        "确认送达",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
                //订单详情
        buttonOrderInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Order(
                        order_bean.getOid(),
                        order_bean.getSid(),
                        order_bean.getSName(),
                        order_bean.getSAdress(),
                        order_bean.getSPhone(),
                        order_bean.getCid(),
                        order_bean.getCAdress(),
                        order_bean.getCPhone(),
                        order_bean.getCName(),
                        order_bean.getRid(),
                        order_bean.getRName(),
                        order_bean.getRPhone(),
                        order_bean.getBillingTime(),
                        order_bean.getAcceptTime(),
                        order_bean.getFinishTime(),
                        order_bean.getSalary(),
                        order_bean.getTotal_Price(),
                        order_bean.isSTaken(),
                        order_bean.isRTaken(),
                        order_bean.isDelivery(),
                        order_bean.isConfirm()
                );
            }
        });

    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,1000,280);
//        frameTest.add(new SingleRiderOrder_Panel("店家1",
//                "2019年8月24日09:38:09",
//                "xxxxxxxxx111111111111",
//                "xxxxxxxxx111111111111",
//                "3.5",
//                false,
//                false,
//                false,
//                false,
//                0));
        frameTest.setVisible(true);
    }
}
