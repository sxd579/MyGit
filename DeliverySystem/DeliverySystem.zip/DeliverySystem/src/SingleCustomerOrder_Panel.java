import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleCustomerOrder_Panel extends JPanel {
    public SingleCustomerOrder_Panel(String storeName ,
                                     String time,
                                     String total_Price,
                                     boolean isSTaken,
                                     boolean isRTaken,
                                     boolean isDelivery,
                                     boolean isConfirm,
                                     int num,
                                     String storeId,
                                     String riderId,
                                     Order_Bean order_bean){
        this.setLayout(new GridLayout(5,1));
        this.setBounds(20,20+280*num,530,250);
        this.setBackground(Color.white);
        JLabel labelName = new JLabel("店名:"+storeName);
        JLabel labelTime = new JLabel("下单时间:"+time);
        JLabel labelMoney = new JLabel("总价格:￥"+total_Price);
        JPanel panelOrderInfo = new JPanel();
        panelOrderInfo.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelStatus = new JLabel();
        JButton buttonOrderInfo = new JButton("订单详情");
        buttonOrderInfo.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        buttonOrderInfo.setBackground(Color.cyan);
        buttonOrderInfo.setOpaque(false);
        JPanel panelBt = new JPanel();
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelBt.setOpaque(false);
        JButton buttonContact = new JButton("联系骑手/商家");
        JButton buttonConfirm = new JButton("确认收货");
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        labelTime.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        labelMoney.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        labelStatus.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        buttonContact.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        buttonConfirm.setFont(new Font("微软雅黑", Font.BOLD, 20));;
        buttonContact.setBackground(Color.cyan);
        buttonContact.setOpaque(false);
        buttonConfirm.setBackground(Color.cyan);
        buttonConfirm.setOpaque(false);
        if (!isSTaken){
            labelStatus.setText("订单状态:等待商家接单……");
        }
        if (isSTaken&&!isRTaken){
            labelStatus.setText("订单状态:正在寻找骑手ing……");
        }
        if (isSTaken&&isRTaken&&!isDelivery){
            labelStatus.setText("订单状态:骑手正在配送ing……");
        }
        if (isSTaken&&isRTaken&&isDelivery){
            labelStatus.setText("订单状态:骑手已送达，等待客户确认送达……");
        }
        if (isSTaken&&isRTaken&&isDelivery&&isConfirm){
            labelStatus.setText("订单状态:已送达");
        }

        if (isRTaken) {
            if (isConfirm) {
                panelBt.add(buttonOrderInfo);
                panelBt.add(buttonContact);
            } else {
                panelBt.add(buttonOrderInfo);
                panelBt.add(buttonContact);
                panelBt.add(buttonConfirm);

            }
        }
        else {
            panelBt.add(buttonOrderInfo);
            panelBt.add(buttonContact);
        }
        buttonConfirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //弹出评价界面，分别是对骑手和商家  通过id 对商家和骑手分别评价记录
                Server_API.customerConfirm(order_bean.getOid());
                new DS_Confirm_Say(order_bean.getCid(),order_bean.getSid(),order_bean.getRid(),order_bean.getCName());
            }
        });

        //联系商家，骑手
        buttonContact.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        new JLabel("<html><h2><font color='red'><font size=\"25\"> 商家电话:  "+order_bean.getSPhone()+"<br>" +
                                "骑手电话:  "+order_bean.getRPhone()+"<br></font></h2></html>"),
                        "确认送达",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        buttonOrderInfo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DS_Order(
                        order_bean.getOid(),
                        order_bean.getSid(),
                        order_bean.getSName(),
                        order_bean.getSAdress(),
                        order_bean.getSPhone(),
                        order_bean.getCid(),
                        order_bean.getCAdress(),
                        order_bean.getCPhone(),
                        order_bean.getCName(),
                        order_bean.getRid(),
                        order_bean.getRName(),
                        order_bean.getRPhone(),
                        order_bean.getBillingTime(),
                        order_bean.getAcceptTime(),
                        order_bean.getFinishTime(),
                        order_bean.getSalary(),
                        order_bean.getTotal_Price(),
                        order_bean.isSTaken(),
                        order_bean.isRTaken(),
                        order_bean.isDelivery(),
                        order_bean.isConfirm()
                            );
            }
        });
        this.add(labelName);
        this.add(labelTime);
        this.add(labelMoney);
        this.add(labelStatus);
        this.add(panelBt);



    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,550,280);
//        frameTest.add(new SingleCustomerOrder_Panel("LOL","2019年8月22日16:37:31","35",true,true,true,false,0,null,null));
        frameTest.setVisible(true);
    }
}
