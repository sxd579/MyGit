import javax.swing.*;
import java.awt.*;

public class SingleOrder_Panel extends JPanel {
    public SingleOrder_Panel(String name,String singleCost, String many, int num){
        this.setBounds(20,20+80*num,400,50);
        this.setLayout(new GridLayout(1,3));
        this.setBackground(Color.white);
        JLabel labelName = new JLabel("商品名:"+name);
        labelName.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelSingleCost = new JLabel("单价:￥"+singleCost);
        labelSingleCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JLabel labelMany = new JLabel("数量:*"+many);
        labelMany.setFont(new Font("微软雅黑", Font.BOLD, 20));
        this.add(labelName);
        this.add(labelSingleCost);
        this.add(labelMany);
    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,400,100);
        frameTest.add(new SingleOrder_Panel("田鸭","35","3",0));
        frameTest.setVisible(true);
    }
}
