import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class DS_Order {
    String oid;
    String sid;
    String sName;
    String sAdress;
    String sPhone;
    String cid;
    String cName;
    String cAdress;
    String cPhone;
    String rid;
    String rName;
    String rPhone;
    String billingTime;
    String acceptTime;
    String finishTime;
    String salary;
    String total_Price;
    boolean isSTaken;
    boolean isRTaken;
    boolean isDelivery;
    boolean isConfirm;
    ArrayList<Good_Bean> good_beans = new ArrayList <Good_Bean>();
    public DS_Order(
                    String oid,
                    String sid,
                    String sName,
                    String sAdress,
                    String sPhone,
                    String cid,
                    String cAdress,
                    String cPhone,
                    String cName,
                    String rid,
                    String rName,
                    String rPhone,
                    String billingTime,
                    String acceptTime,
                    String finishTime,
                    String salary,
                    String total_Price,
                    boolean isSTaken,
                    boolean isRTaken,
                    boolean isDelivery,
                    boolean isConfirm
    ){
        this.oid = oid;
        this.sid = sid;
        this.sName = sName;
        this.sAdress = sAdress;
        this.sPhone = sPhone;
        this.rid = rid;
        this.rName = rName;
        this.rPhone = rPhone;
        this.cid = cid;
        this.cName = cName;
        this.cAdress = cAdress;
        this.cPhone = cPhone;
        this.billingTime = billingTime;
        this.acceptTime = acceptTime;
        this.finishTime = finishTime;
        this.salary = salary;
        this.total_Price = total_Price;
        this.isSTaken = isSTaken;
        this.isRTaken = isRTaken;
        this.isDelivery = isDelivery;
        this.isConfirm = isConfirm;
        good_beans = Server_API.getOrderGoods(oid);
        order(oid);
    }
    public void order(String oid){
        JFrame frameOrder = new JFrame("订单号:"+oid);
        frameOrder.setBounds(600,200,950,750);
        JPanel panelOrder = new JPanel();
        panelOrder.setLayout(null);
        panelOrder.setBackground(new Color(252,230,201));
        JPanel panelOrderInfo = new JPanel();
        panelOrderInfo.setBackground(new Color(176,224,230));
        panelOrderInfo.setLayout(new GridLayout(11,2));
        panelOrderInfo.setBounds(20,50,400,650);

        JPanel panelCustomer = new JPanel();
        panelCustomer.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelCustomer = new JLabel("顾客:");
        labelCustomer.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCustomer = new JTextField(8);
        textFieldCustomer.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCustomer.setEditable(false);
        panelCustomer.setBackground(new Color(176,224,230));
        textFieldCustomer.setBackground(Color.white);
        textFieldCustomer.setText(cName);

        JPanel panelRider = new JPanel();
        panelRider.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelRider = new JLabel("骑手:");
        labelRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldRider = new JTextField(8);
        textFieldRider.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldRider.setEditable(false);
        panelRider.setBackground(new Color(176,224,230));
        textFieldRider.setBackground(Color.white);
        textFieldRider.setText(rName);

        JPanel panelStore = new JPanel();
        panelStore.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelStore = new JLabel("商家:");
        labelStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldStore = new JTextField(10);
        textFieldStore.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldStore.setEditable(false);
        panelStore.setBackground(new Color(176,224,230));
        textFieldStore.setBackground(Color.white);
        textFieldStore.setText(sName);

        JPanel panelCAdress = new JPanel();
        panelCAdress.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelCAdress = new JLabel("收货地址:");
        labelCAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCAdress = new JTextField(12);
        textFieldCAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCAdress.setEditable(false);
        panelCAdress.setBackground(new Color(176,224,230));
        textFieldCAdress.setBackground(Color.white);
        textFieldCAdress.setText(cAdress);

        JPanel panelSAdress = new JPanel();
        panelSAdress.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelSAdress = new JLabel("取货地址:");
        labelSAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldSAdress = new JTextField(12);
        textFieldSAdress.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldSAdress.setEditable(false);
        panelSAdress.setBackground(new Color(176,224,230));
        textFieldSAdress.setBackground(Color.white);
        textFieldSAdress.setText(sAdress);

        JPanel panelSalary = new JPanel();
        panelSalary.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelSalary = new JLabel("配送费: ￥");
        labelSalary.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldSalary = new JTextField(4);
        textFieldSalary.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldSalary.setEditable(false);
        panelSalary.setBackground(new Color(176,224,230));
        textFieldSalary.setBackground(Color.white);
        textFieldSalary.setText(salary);

        JPanel panelCost = new JPanel();
        panelCost.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelCost = new JLabel("总价格: ￥");
        labelCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCost = new JTextField(4);
        textFieldCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCost.setEditable(false);
        panelCost.setBackground(new Color(176,224,230));
        textFieldCost.setBackground(Color.white);
        textFieldCost.setText(total_Price);

        JPanel panelCPhone = new JPanel();
        panelCPhone.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelCPhone = new JLabel("顾客电话:");
        labelCPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCPhone = new JTextField(13);
        textFieldCPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldCPhone.setEditable(false);
        panelCPhone.setBackground(new Color(176,224,230));
        textFieldCPhone.setBackground(Color.white);
        textFieldCPhone.setText(cPhone);

        JPanel panelRPhone = new JPanel();
        panelRPhone.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel labelRPhone = new JLabel("骑手电话:");
        labelRPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldRPhone = new JTextField(13);
        textFieldRPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldRPhone.setEditable(false);
        panelRPhone.setBackground(new Color(176,224,230));
        textFieldRPhone.setBackground(Color.white);
        textFieldRPhone.setText(rPhone);

        JPanel panelSPhone = new JPanel();
        panelSPhone.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelSPhone.setBackground(new Color(176,224,230));
        JLabel labelSPhone = new JLabel("商家电话:");
        labelSPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldSPhone = new JTextField(13);
        textFieldSPhone.setFont(new Font("微软雅黑", Font.BOLD, 20));
        textFieldSPhone.setEditable(false);
        textFieldSPhone.setBackground(Color.white);
        textFieldSPhone.setText(sPhone);

        JLabel labelStatus = new JLabel("");
        labelStatus.setFont(new Font("微软雅黑", Font.BOLD, 20));
        if (!isSTaken){
            labelStatus.setText("订单状态:等待商家接单……");
        }
        else if (isSTaken&&!isRTaken){
            labelStatus.setText("订单状态:正在寻找骑手ing……");
        }
        else if (isSTaken&&isRTaken&&!isDelivery){
            labelStatus.setText("订单状态:骑手正在配送ing……");
        }
        else if (isSTaken&&isRTaken&&isDelivery){
            labelStatus.setText("订单状态:骑手已送达，等待客户确认送达……");
        }
        else if (isSTaken&&isRTaken&&isDelivery&&isConfirm){
            labelStatus.setText("订单状态:已送达");
        }


        JLabel labelMenu = new JLabel("商品列表:");
        labelMenu.setFont(new Font("微软雅黑", Font.BOLD, 20));
        labelMenu.setBounds(420,0,250,50);

        panelCustomer.add(labelCustomer);
        panelCustomer.add(textFieldCustomer);
        panelRider.add(labelRider);
        panelRider.add(textFieldRider);
        panelStore.add(labelStore);
        panelStore.add(textFieldStore);
        panelCAdress.add(labelCAdress);
        panelCAdress.add(textFieldCAdress);
        panelSAdress.add(labelSAdress);
        panelSAdress.add(textFieldSAdress);
        panelSalary.add(labelSalary);
        panelSalary.add(textFieldSalary);
        panelCost.add(labelCost);
        panelCost.add(textFieldCost);
        panelCPhone.add(labelCPhone);
        panelCPhone.add(textFieldCPhone);
        panelRPhone.add(labelRPhone);
        panelRPhone.add(textFieldRPhone);
        panelSPhone.add(labelSPhone);
        panelSPhone.add(textFieldSPhone);
        panelOrderInfo.add(panelCustomer);
        panelOrderInfo.add(panelRider);
        panelOrderInfo.add(panelStore);
        panelOrderInfo.add(panelCAdress);
        panelOrderInfo.add(panelSAdress);
        panelOrderInfo.add(panelSalary);
        panelOrderInfo.add(panelCost);
        panelOrderInfo.add(panelCPhone);
        panelOrderInfo.add(panelRPhone);
        panelOrderInfo.add(panelSPhone);
        panelOrderInfo.add(labelStatus);
        panelOrder.add(panelOrderInfo);
        panelOrder.add(labelMenu);

        JPanel panelMenu = new JPanel();
        panelMenu.setOpaque(false);
        panelMenu.setLayout(null);
        panelMenu.setBounds(430,50,500,680);
        JPanel panelGood = new JPanel();
        panelGood.setLayout(null);
        panelGood.setBackground(new Color(176,224,230));
        JScrollPane scrollPaneGood = new JScrollPane(panelGood);
        scrollPaneGood.setBounds(0,0,450,620);
        int height = 0;
        for (int i = 0;i<good_beans.size();i++){
            panelGood.add(new SingleOrder_Panel(good_beans.get(i).getName(),good_beans.get(i).getPrice(),good_beans.get(i).getMany(),i));
            panelGood.revalidate();
            height+=200;
        }
        panelGood.setPreferredSize(new Dimension(scrollPaneGood.getWidth(),height));





        panelMenu.add(scrollPaneGood);
        frameOrder.add(panelMenu);
        frameOrder.add(panelOrder);
        frameOrder.setVisible(true);
        frameOrder.setResizable(false);
    }

    public static void main(String[] args) {
//        new DS_Order("",false,false,false,false);
    }
}
