public class Order_Bean {
    private String SPhone;
    private String SAdress;
    private String SName;
    private String CPhone;
    private String CAdress;
    private String CName;
    private String RPhone;
    private String RName;
    private String oid;
    private String sid;
    private String cid;
    private String rid;
    private String billingTime;
    private String acceptTime;
    private String finishTime;
    private String salary;
    private String total_Price;
    private boolean isRTaken;
    private boolean isSTaken;
    private boolean isDelivery;
    private boolean isConfirm;
    private boolean isAdd = false;

    public boolean isAdd() {
        return isAdd;
    }

    public void setAdd(boolean add) {
        isAdd = add;
    }

    public String getSPhone() {
        return SPhone;
    }

    public void setSPhone(String SPhone) {
        this.SPhone = SPhone;
    }

    public String getSAdress() {
        return SAdress;
    }

    public void setSAdress(String SAdress) {
        this.SAdress = SAdress;
    }

    public String getCPhone() {
        return CPhone;
    }

    public void setCPhone(String CPhone) {
        this.CPhone = CPhone;
    }

    public String getCAdress() {
        return CAdress;
    }

    public void setCAdress(String CAdress) {
        this.CAdress = CAdress;
    }

    public String getRPhone() {
        return RPhone;
    }

    public void setRPhone(String rPhone) {
        this.RPhone = rPhone;
    }

    public String getSName() {
        return SName;
    }

    public void setSName(String SName) {
        this.SName = SName;
    }

    public String getCName() {
        return CName;
    }

    public void setCName(String CName) {
        this.CName = CName;
    }

    public String getRName() {
        return RName;
    }

    public void setRName(String RName) {
        this.RName = RName;
    }

    public String getOid() {
        return oid;
    }

    public void setOid(String oid) {
        this.oid = oid;
    }

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getBillingTime() {
        return billingTime;
    }

    public void setBillingTime(String billingTime) {
        this.billingTime = billingTime;
    }

    public String getAcceptTime() {
        return acceptTime;
    }

    public void setAcceptTime(String acceptTime) {
        this.acceptTime = acceptTime;
    }

    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getTotal_Price() {
        return total_Price;
    }

    public void setTotal_Price(String total_Price) {
        this.total_Price = total_Price;
    }

    public boolean isRTaken() {
        return isRTaken;
    }

    public void setRTaken(boolean RTaken) {
        isRTaken = RTaken;
    }

    public boolean isSTaken() {
        return isSTaken;
    }

    public void setSTaken(boolean STaken) {
        isSTaken = STaken;
    }

    public boolean isDelivery() {
        return isDelivery;
    }

    public void setDelivery(boolean delivery) {
        isDelivery = delivery;
    }

    public boolean isConfirm() {
        return isConfirm;
    }

    public void setConfirm(boolean confirm) {
        isConfirm = confirm;
    }


}
