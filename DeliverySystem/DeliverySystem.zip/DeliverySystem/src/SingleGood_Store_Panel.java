import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SingleGood_Store_Panel extends JPanel {
    public int getNumber() {
        return number;
    }

    private int number;
    private int odNums;
    public SingleGood_Store_Panel(String sid,String name,String intro,String price,Good_Bean good_bean,int num){
        number = num;
        this.setLayout(new GridLayout(4,2));
        //
        this.setBackground(Color.white);
        this.setBounds(50,20+220*num,400,200);
        JTextField textFieldName = new JTextField(name);
        textFieldName.setOpaque(false);
        textFieldName.setFont(new Font("微软雅黑", Font.BOLD, 25));
        JTextField textFieldIntro = new JTextField(intro);
        textFieldIntro.setOpaque(false);
        textFieldIntro.setFont(new Font("微软雅黑", Font.BOLD, 15));
        JPanel panelCost = new JPanel();
        panelCost.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelCost.setOpaque(false);
        JLabel labelCost =new JLabel("￥");
        labelCost.setFont(new Font("微软雅黑", Font.BOLD, 20));
        JTextField textFieldCost = new JTextField(price);
        textFieldCost.setFont(new Font("微软雅黑", Font.BOLD, 20));

        //点餐
        JPanel panelBt = new JPanel();
        panelBt.setOpaque(false);
        panelBt.setLayout(new FlowLayout(FlowLayout.LEFT));
        JButton buttonChange = new JButton("确认修改");
        buttonChange.setFont(new Font("微软雅黑", Font.BOLD, 20));
        buttonChange.setBackground(Color.cyan);
        buttonChange.setOpaque(false);
        buttonChange.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(Server_API.updateGood(textFieldName.getText(),textFieldIntro.getText(),textFieldCost.getText(),good_bean)){
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 修改成功</font></h2></html>"),
                            "修改成功",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                else {
                    JOptionPane.showMessageDialog(null,
                            new JLabel("<html><h2><font color='red'><font size=\"25\"> 修改失败</font></h2></html>"),
                            "修改失败",
                            JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });
        panelCost.add(labelCost);
        panelCost.add(textFieldCost);
        panelBt.add(buttonChange);
        this.add(textFieldName);
        this.add(textFieldIntro);
        this.add(panelCost);
        this.add(panelBt);
    }

    public static void main(String[] args) {
        JFrame frameTest =new JFrame();
        frameTest.setBounds(600,200,500,250);
//        frameTest.add(new SingleGood_Store_Panel("田鸭","主要原料:鸭肉","35",1));
        frameTest.setVisible(true);
    }
}
